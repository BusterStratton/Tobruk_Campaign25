<?php
/**
 * Plugin Name: My Bad Boy List
 * Plugin URI: https://yourwebsite.com
 * Description: Logs and displays detected cheaters in a file.
 * Version: 1.0
 * Author: TWC_Fatal_Error
 * Author URI: https://yourwebsite.com
 */

if (!defined('ABSPATH')) {
    exit; // Prevent direct access
}

// Define the file path to store cheaters
define('MBBL_FILE_PATH', plugin_dir_path(__FILE__) . 'cheaters.txt');

/**
 * Handle incoming POST request to log cheaters
 */
function mbbl_receive_cheater_log() {
    if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['cheater_data'])) {
        $cheater_data = sanitize_text_field($_POST['cheater_data']);
        
        if (!empty($cheater_data)) {
            file_put_contents(MBBL_FILE_PATH, $cheater_data . PHP_EOL, FILE_APPEND | LOCK_EX);
            wp_send_json_success("Cheater logged successfully.");
        } else {
            wp_send_json_error("No data received.");
        }
    }
}
add_action('admin_post_nopriv_mbbl_log_cheater', 'mbbl_receive_cheater_log');
add_action('admin_post_mbbl_log_cheater', 'mbbl_receive_cheater_log');

/**
 * Shortcode to display the cheater list
 */
function mbbl_display_cheater_list() {
    if (!file_exists(MBBL_FILE_PATH)) {
        return "No cheaters logged yet.";
    }

    $cheater_list = file_get_contents(MBBL_FILE_PATH);
    return "<pre>" . esc_html($cheater_list) . "</pre>";
}
add_shortcode('cheater_list', 'mbbl_display_cheater_list');

/**
 * Create the cheaters.txt file on plugin activation
 */
function mbbl_create_file() {
    if (!file_exists(MBBL_FILE_PATH)) {
        file_put_contents(MBBL_FILE_PATH, "=== Cheater Log Started ===\n", LOCK_EX);
    }
}
register_activation_hook(__FILE__, 'mbbl_create_file');

/**
 * Add settings page for manual review (optional)
 */
function mbbl_add_admin_menu() {
    add_menu_page(
        'My Bad Boy List',
        'Cheater List',
        'manage_options',
        'my-bad-boy-list',
        'mbbl_admin_page',
        'dashicons-warning',
        20
    );
}
add_action('admin_menu', 'mbbl_add_admin_menu');

/**
 * Admin page content
 */
function mbbl_admin_page() {
    echo '<div class="wrap"><h1>Cheater Log</h1>';
    echo '<p>Below is the current list of detected cheaters:</p>';
    echo '<pre style="background:#f9f9f9; padding:10px;">' . esc_html(@file_get_contents(MBBL_FILE_PATH)) . '</pre>';
    echo '</div>';
}
