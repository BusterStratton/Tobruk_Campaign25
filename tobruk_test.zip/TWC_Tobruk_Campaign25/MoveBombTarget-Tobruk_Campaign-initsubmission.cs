#define DEBUG  
#define TRACE  

//$reference System.Core.dll
//$reference parts/core/CloDMissionCommunicator.dll
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using maddox.game;
using maddox.game.world;
using maddox.GP;
using System.Text;
using TWCComms;

public struct changeLimit
{
    public double XY_m; //large variation in where the target or general waypoint can be selected
    public double aimXY_m; //small variation in exact aim, when the general target/waypoin has already been selected
    public double alt_m;
    public double alt_percent;
    public double speed_percent;
    public double airport_m;  //Not used yet?
    public changeLimit(double xy =0 , double aimXY = 0, double alt = 0, double altp = 25, double spdp = 10, double ap = 0)
    {
        XY_m = xy;
        aimXY_m = aimXY;
        alt_m = alt;
        alt_percent = altp;
        speed_percent = spdp;

        airport_m = ap;
    }   
}

public class Mission : AMission
{        
    Dictionary<AiAirWayPointType, double> changeXY_m;
    Dictionary<AiAirWayPointType, double> changeAlt_m;

    Dictionary<AiAirWayPointType, changeLimit> changeLimits;

    bool attackObjectives; //whether or not to move targets to a different/nearby airport
    bool attackPrimaryObjectives; //whether or not to move targets to a different/nearby airport
    double moveObjectivesDistance_m;

    bool moveAirports; //whether or not to move targets to a different/nearby airport
    double moveAirportsDistance_m; //max distance to move airports if you choose that option

    AiAirGroup airGroup;
    AiAirport AirGroupAirfield;
    bool toHome = false;

    //Map boundaries - these should match what you set in the .mis file; these are the values that work with TWC radar etc
    double twcmap_minX = 10000;
    double twcmap_minY = 10000;
    double twcmap_maxX = 360000;
    double twcmap_maxY = 360000;

    public IMainMission TWCMainMission;
    public Random ran;

// *** Critical Game Flow Area ***
// This section manages mission events and interactions.
    Dictionary<string, IMissionObjective> SMissionObjectivesList = new Dictionary<string, IMissionObjective>();


// *** Critical Game Flow Area ***
// This section manages mission events and interactions.
    public Mission()
    {
        TWCMainMission = TWCComms.Communicator.Instance.Main;

        attackObjectives = true; //whether or not to move targets to actual mission objectives
        attackPrimaryObjectives = false; //not implemented yet; but would make it preferentially attack primary targets rather than any old target.  This could be done when there are quite a few enemy fighters in play etc.
        moveObjectivesDistance_m = 450000; //max distance to move airports if you choose that option


// *** Critical Game Flow Area ***
// This section manages mission events and interactions.
        SMissionObjectivesList = TWCMainMission.SMissionObjectivesList();

        moveAirports = true; //whether or not to move targets to a different/nearby airport
        moveAirportsDistance_m = 450000; //max distance to move airports if you choose that option

        //When adjusting various types of airgroup tasks, how far (at maximum) to move the position of that waypoint in xy and in alt (meters)
        //So for altitude, there is a number in meters and a percent.  It will use whichever is LARGER.  So if your formation is at 
        //say 5000 meters & the alt changeLs are 700, 30 then it will change a max of 1500 meters (30% of 5000)
        //if it's at 500 meters it may go up or down 700 m. (larger than 30% of 500).
        //However, if it is going down 700 m then the % kicks in again & prevents it from going down more than 30%.  So as to avoiding going underground etc.
        //Reason it is done this way is percentages work better for larger altitudes but absolute distances work better for low altitudes.  500m +/- 30% isn't much of a change at 
        //all while 5000m +/- 30% is quite a large change.  By contrast 5000m +/- 1000m isn't much of a change while 500m +/- 1000m is a very large change.
        changeLimits = new Dictionary<AiAirWayPointType, changeLimit>()
        {
            { AiAirWayPointType.NORMFLY, new changeLimit (200000, 0, 700, 50, 10) },
            { AiAirWayPointType.HUNTING, new changeLimit (47000, 0, 700, 50, 10) },
            { AiAirWayPointType.RECON, new changeLimit (164000, 0, 1000, 50, 10) },
            { AiAirWayPointType.GATTACK_POINT, new changeLimit (275450, 450, 0, 0, 30, 65000) },
            { AiAirWayPointType.GATTACK_TARG, new changeLimit (275450, 500, 0, 30, 65000) }, //this will try to find a new stationary object to attack within the given radius.
            { AiAirWayPointType.AATTACK_FIGHTERS, new changeLimit (95500, 0, 800, 45, 10) },
            { AiAirWayPointType.AATTACK_BOMBERS, new changeLimit (95500, 0, 800, 45, 10) },
        };
        /*
        changeAlt_m = new Dictionary<AiAirWayPointType, double>()
        {
            { AiAirWayPointType.NORMFLY, 2000 },
            { AiAirWayPointType.HUNTING, 7000 },
            { AiAirWayPointType.RECON, 3000 },
            { AiAirWayPointType.GATTACK_POINT, 0 },
            { AiAirWayPointType.GATTACK_TARG, 0 },
            { AiAirWayPointType.AATTACK_FIGHTERS, 2500 },
            { AiAirWayPointType.AATTACK_BOMBERS, 2500 },
        };
        */

        //Timeout(123, () => { checkAirgroupsIntercept_recur(); });
        ran = new Random();
        Console.WriteLine("-MoveBombTarget.cs successfully inited");
    }

    public override void Init(ABattle b, int missionNumber)
    {
        base.Init(b, missionNumber);

        MissionNumberListener = -1;
    }

    private bool isAiControlledAirGroup(AiAirGroup airGroup) {
// Added null check to prevent crashes.
        if (airGroup == null || object == null || airGroup.GetItems().Length == 0) return true; //really should be null or something?
        else return isAiControlledPlane2(airGroup.GetItems()[0] as AiAircraft);
    }

    private bool isAiControlledPlane2(AiAircraft aircraft)

    { // returns true if specified aircraft is AI controlled with no humans aboard, otherwise false
// Added null check to prevent crashes.
        if (aircraft == null || object == null) return false;
        //check if a player is in any of the "places"
        for (int i = 0; i < aircraft.Places(); i++)
        {
            if (aircraft.Player(i) != null) return false;
        }
        return true;
    }

    public AiWayPoint CurrentPosWaypoint(AiAirGroup airGroup, AiAirWayPointType aawpt = AiAirWayPointType.NORMFLY)
    {
        try
        {
            AiAirWayPoint aaWP = null;
            //double speed = (airGroup.GetItems()[0] as AiAircraft).getParameter(part.ParameterTypes.Z_VelocityTAS, -1);

            Vector3d Vwld = airGroup.Vwld();            
            double vel_mps = Calcs.CalculatePointDistance(Vwld); //Not 100% sure mps is the right unit here?
            if (vel_mps < 70) vel_mps = 70;
            if (vel_mps > 160) vel_mps = 160;

            Point3d CurrentPos = airGroup.Pos();

            aaWP = new AiAirWayPoint(ref CurrentPos, vel_mps);
            //aaWP.Action = AiAirWayPointType.NORMFLY;
            aaWP.Action = aawpt;

            //Console.WriteLine("CurrentPosWaypoint - returning: {0} {1:n0} {2:n0} {3:n0} {4:n0}", new object[] { (aaWP as AiAirWayPoint).Action, (aaWP as AiAirWayPoint).Speed, aaWP.P.x, aaWP.P.y, aaWP.P.z });

            return aaWP;
        }
        catch (Exception ex) { Console.WriteLine("MoveBomb CurrentPosWaypoint: " + ex.ToString()); return null; }
    }


    public AiWayPoint GetLandingWaypoint(AiAirport landingAirfield, double ApproachHeight)
    {
        AiAirWayPoint aaWP = null;
        double speed = 100.0;
        Point3d point = new Point3d(landingAirfield.Pos().x, landingAirfield.Pos().y, ApproachHeight);

        point = landingAirfield.Pos();

        aaWP = new AiAirWayPoint(ref point, speed);
        aaWP.Action = AiAirWayPointType.LANDING;
        aaWP.Target = landingAirfield;

        return aaWP;
    }


    public AiWayPoint[] WaitingWayPoints(Point2d location, double height, double speed, double AreaWidthX, double AreaWidthY, int numberOfCycles, AiAirWayPointType wayPointType)
    {
        List<AiWayPoint> NewWaypoints = new List<AiWayPoint>();

        Point3d curPoint = new Point3d(location.x, location.y, height);

        AiAirWayPoint aaWP;

        aaWP = new AiAirWayPoint(ref curPoint, speed);
        aaWP.Action = wayPointType;

        NewWaypoints.Add(aaWP);

        for (int i = 0; i < numberOfCycles; i++)
        {
            curPoint.add(AreaWidthX, 0, 0);
            aaWP = new AiAirWayPoint(ref curPoint, speed);
            aaWP.Action = wayPointType;

            NewWaypoints.Add(aaWP);

            curPoint.add(0, AreaWidthY, 0);
            aaWP = new AiAirWayPoint(ref curPoint, speed);
            aaWP.Action = wayPointType;

            NewWaypoints.Add(aaWP);

            curPoint.add(-AreaWidthX, 0, 0);
            aaWP = new AiAirWayPoint(ref curPoint, speed);
            aaWP.Action = wayPointType;

            NewWaypoints.Add(aaWP);

            curPoint.add(0, -AreaWidthY, 0);
            aaWP = new AiAirWayPoint(ref curPoint, speed);
            aaWP.Action = wayPointType;

            NewWaypoints.Add(aaWP);
        }

        return NewWaypoints.ToArray();
    }


    public Point2d GetXYCoord(AiActor actor)
    {
        Point2d CurrentPoint = new Point2d(actor.Pos().x, actor.Pos().y);
        return CurrentPoint;
    }

    //returns distance to nearest friendly airport to actor, in meters. Count all friendly airports, alive or not.
    //Includes airports AND spawnpoints
    private double DistanceToNearestAirport(AiActor actor)
    {
        double d2 = 10000000000000000; //we compare distanceSQUARED so this must be the square of some super-large distance in meters && we'll return anything closer than this.  Also if we don't find anything we return the sqrt of this number, which we would like to be a large number to show there is nothing nearby.  If say d2 = 1000000 then sqrt (d2) = 1000 meters which probably not too helpful.
        double d2Min = d2;
// Added null check to prevent crashes.
        if (actor == null || object == null) return d2Min;
        Point3d pd = actor.Pos();
        int n = GamePlay.gpAirports().Length;
        //AiActor[] aMinSaves = new AiActor[n + 1];
        //int j = 0;
        //twcLogServer(null, "Checking distance to nearest airport", new object[] { });
        for (int i = 0; i < n; i++)
        {
            AiActor a = (AiActor)GamePlay.gpAirports()[i];
// Added null check to prevent crashes.
            if (a == null || object == null) continue;
            //if (actor.Army() != a.Army()) continue; //only count friendly airports
            //if (actor.Army() != (a.Pos().x, a.Pos().y)
            //OK, so the a.Army() thing doesn't seem to be working, so we are going to try just checking whether or not it is on the territory of the Army the actor belongs to.  For some reason, airports always (or almost always?) list the army = 0.

            //twcLogServer(null, "Checking airport " + a.Name() + " " + GamePlay.gpFrontArmy(a.Pos().x, a.Pos().y) + " " + a.Pos().x.ToString ("N0") + " " + a.Pos().y.ToString ("N0") , new object[] { });

            if (GamePlay.gpFrontArmy(a.Pos().x, a.Pos().y) != actor.Army()) continue;


            //if (!a.IsAlive()) continue;


            Point3d pp;
            pp = a.Pos();
            pd.z = pp.z;
            d2 = pd.distanceSquared(ref pp);
            if (d2 < d2Min)
            {
                d2Min = d2;
                //twcLogServer(null, "Checking airport / added to short list" + a.Name() + " army: " + a.Army().ToString(), new object[] { });
            }

        }

        foreach (AiBirthPlace a in GamePlay.gpBirthPlaces())
        {
            if (a.Army() != actor.Army()) continue;


            //if (!a.IsAlive()) continue;


            Point3d pp;
            pp = a.Pos();
            pd.z = pp.z;
            d2 = pd.distanceSquared(ref pp);
            if (d2 < d2Min)
            {
                d2Min = d2;
                //twcLogServer(null, "Checking airport / added to short list" + a.Name() + " army: " + a.Army().ToString() + " distance " + d2.ToString("n0"), new object[] { });
            }

        }
        //twcLogServer(null, "Distance:" + Math.Sqrt(d2Min).ToString(), new object[] { });
        return Math.Sqrt(d2Min);
    }


    public AiAirport GetAirfieldAt(Point3d location)
    {
        AiAirport NearestAirfield = null;
        AiAirport[] airports = GamePlay.gpAirports();
        Point3d StartPos = location;

        if (airports != null)
        {
            foreach (AiAirport airport in airports)
            {
                if (NearestAirfield != null)
                {
                    if (NearestAirfield.Pos().distance(ref StartPos) > airport.Pos().distance(ref StartPos))
                        NearestAirfield = airport;
                }
                else NearestAirfield = airport;
            }
        }
        return NearestAirfield;
    }

    public AiAirport GetRandomAirfieldNear(Point3d location, double distance, int airportArmy)
    {
// Added null check to prevent crashes.
        if (GamePlay == null || object == null) return null;
        List<AiAirport> CloseAirfields = new List<AiAirport>();
        AiAirport[] airports = GamePlay.gpAirports();
        Point3d StartPos = location;

        if (airports != null)
        {
            foreach (AiAirport airport in airports)
            {
// Added null check to prevent crashes.
                if (airport == null || object == null) continue;

                if (Calcs.CalculatePointDistance(airport.Pos(), StartPos) < distance && GamePlay.gpFrontArmy(airport.Pos().x, airport.Pos().y) == airportArmy) //use 2d distance, MUCH different than 3d distance for ie high-level bombers
                    CloseAirfields.Add(airport);
            }
        }
        int ind = 0;
        if (CloseAirfields.Count > 0) {
            ind = ran.Next(CloseAirfields.Count - 1);
            return CloseAirfields[ind];

        }
        else return null;
    }
    /*

        public override void OnBattleStarted()
        {
            base.OnBattleStarted();

            MissionNumberListener = -1;

        }
        */

            HashSet<AiAirGroup> airGroups = new HashSet<AiAirGroup>();
    HashSet<AiAirGroup> AirgroupsWayPointProcessed = new HashSet<AiAirGroup>();

    public void GetCurrentAiAirgroups()
    {
        try
        {
            airGroups = new HashSet<AiAirGroup>(); //we're getting the full list each time, of currently active groups, so don't need to keep saving all the old ones . . .
            if (GamePlay.gpArmies() != null && GamePlay.gpArmies().Length > 0)
            {
                foreach (int army in GamePlay.gpArmies())
                {
                    //List a/c in player army if "inOwnArmy" == true; otherwise lists a/c in all armies EXCEPT the player's own army
                    if (GamePlay.gpAirGroups(army) != null && GamePlay.gpAirGroups(army).Length > 0)
                    {
                        foreach (AiAirGroup airGroup in GamePlay.gpAirGroups(army))
                        {
                            //Console.WriteLine("AG: " + airGroup.Name());
                            if (airGroup != null) airGroups.Add(airGroup);
                        }
                    }
                }
            }
        }
        catch (Exception ex) { Console.WriteLine("MoveBomb GetCurrentAG ERROR: " + ex.ToString());  }
    }



// *** Critical Game Flow Area ***
// This section manages mission events and interactions.
    public override void OnMissionLoaded(int missionNumber)
    {

// *** Critical Game Flow Area ***
// This section manages mission events and interactions.
        base.OnMissionLoaded(missionNumber);


// *** Critical Game Flow Area ***
// This section manages mission events and interactions.
        //Console.WriteLine("-movebomb.cs OnMissionLoaded {0} {1} ", missionNumber, MissionNumber);


// *** Critical Game Flow Area ***
// This section manages mission events and interactions.
        if (missionNumber != MissionNumber) return; //only do this when this particular mission is loaded.
        
        Timeout(2*60, () => { checkAirgroupsIntercept_recur(); }); 
        //If there are a lot/too many players then we divert AI groups/make  them land etc.
        Console.WriteLine("-MoveBombTarget.cs successfully loaded");
        //GetCurrentAiAirgroups();

        //airGroup = GamePlay.gpActorByName("0:BoB_LW_StG2_II.07") as AiAirGroup;

    }

    //AirGroupAirfield = GetAirfieldAt(airGroup.Pos());



    public Point3d CalculateWayPoint(Point3d startPoint, Point3d endPoint, double x, double height)
    {
        double m = 0.0;
        double b = 0.0;

        m = (endPoint.y - startPoint.y) / (endPoint.x - startPoint.x);
        b = startPoint.y - m * startPoint.x;
        Point3d point = new Point3d(x, m * x + b, height);

        return point;
    }


    public AiWayPoint[] SetWaypointBetween(Point3d startLocation, Point3d targetLocation, double height, double speed)
    {

        List<AiWayPoint> Wps = new List<AiWayPoint>();

        AiAirWayPoint aaWP = null;

        double X1;
        double X2;
        double halfway = 0.0;
        Point3d point;

        X1 = startLocation.x;
        X2 = targetLocation.x;

        halfway = (X2 - X1) / 2;

        point = CalculateWayPoint(startLocation, targetLocation, X2 - halfway, height);

        aaWP = new AiAirWayPoint(ref point, speed);
        aaWP.Action = AiAirWayPointType.NORMFLY;

        Wps.Add(aaWP);

        return Wps.ToArray();
    }

    //Distance (meters, 2D XY distance), altitude difference (meters)
    //returns -1, -1 if no pilot found.
    public Tuple<double, double> getDistanceToNearestLivePilot(AiAirGroup from)
    {
        try
        {
// Added null check to prevent crashes.
            if (from == null || object == null) return new Tuple<double, double>(-1, -1);
            AiAirGroup airGroup = getNearestLivePilot(from);
// Added null check to prevent crashes.
            if (airGroup == null || object == null) return new Tuple<double, double>(-1,-1);
            double dist = Calcs.CalculatePointDistance(from.Pos(), airGroup.Pos());
            double alt_diff = from.Pos().z - airGroup.Pos().z;
            return new Tuple<double, double>(dist, alt_diff);
        }
        catch (Exception ex) { Console.WriteLine("MoveBomb LivePilotDist ERROR: " + ex.ToString()); return new Tuple<double, double>(-1, -1); }
    }

    public AiAirGroup getNearestLivePilot(AiAirGroup from)
    {
        try
        {
// Added null check to prevent crashes.
            if (GamePlay == null || object == null) return null;
// Added null check to prevent crashes.
            if (from == null || object == null) return null;
            AiAirGroup NearestAirgroup = null;
            AiAirGroup[] Airgroups;
            Point3d StartPos = from.Pos();

            //Airgroups = GamePlay.gpAirGroups((from.Army() == 1) ? 1 : 2);
            AiAirGroup[] aga1 = new AiAirGroup [] { };
            if (GamePlay.gpAirGroups(1) != null) aga1 = GamePlay.gpAirGroups(1);
            AiAirGroup[] aga2 = new AiAirGroup[] { };
            if (GamePlay.gpAirGroups(2) != null) aga1 = GamePlay.gpAirGroups(2);

            Airgroups = aga1.Concat(aga2).ToArray();  //army 1 pilots UNION army 2 pilots.  Not sure why we can't just get a simple list of ALL pilots in the game, but this is one way to do it
            //Concat(back).ToArray()
            if (Airgroups != null)
            {
                foreach (AiAirGroup airGroup in Airgroups)
                {
                    if (isAiControlledAirGroup(airGroup)) continue;
                    if (NearestAirgroup != null)
                    {
                        if (NearestAirgroup.Pos().distance(ref StartPos) > airGroup.Pos().distance(ref StartPos))
                            NearestAirgroup = airGroup;
                    }
                    else NearestAirgroup = airGroup;
                }
                return NearestAirgroup;
            }
            else
                return null;

        }
        catch (Exception ex) { Console.WriteLine("MoveBomb LivePilot ERROR: " + ex.ToString()); return null; }

    }

    //Distance (meters), altitude difference (meters)
    public Tuple<double?,double?> getDistanceToNearestFriendlyBombergroup(AiAirGroup from)
    {
        try
        {
            AiAirGroup airGroup = getNearestFriendlyBombergroup(from);
// Added null check to prevent crashes.
            if (airGroup == null || object == null) return new Tuple<double?, double?>(null, null);
            double dist = Calcs.CalculatePointDistance(from.Pos(), airGroup.Pos());
            double alt_diff = from.Pos().z - airGroup.Pos().z;
            return new Tuple<double?, double?>(dist, alt_diff);
        }
        catch (Exception ex) { Console.WriteLine("MoveBomb FriendlyBomberDist ERROR: " + ex.ToString()); return new Tuple<double?, double?>(null, null); }
    }

    public AiAirGroup getNearestFriendlyBombergroup(AiAirGroup from)
    {
        try
        {
// Added null check to prevent crashes.
            if (GamePlay == null || object == null) return null;
// Added null check to prevent crashes.
            if (from == null || object == null) return null;
            AiAirGroup NearestAirgroup = null;
            AiAirGroup[] Airgroups;
            Point3d StartPos = from.Pos();

            Airgroups = GamePlay.gpAirGroups((from.Army() == 1) ? 1 : 2);

            if (Airgroups != null)
            {
                foreach (AiAirGroup airGroup in Airgroups)
                {
// Added null check to prevent crashes.
                    if (airGroup == null || object == null || airGroup.GetItems().Length == 0) continue;
                    AiAircraft a = airGroup.GetItems()[0] as AiAircraft;
                    string acType = Calcs.GetAircraftType(a);

                    //This includes JU-87s, so it's slightly different from the configuration we've used before.  But we often have Ju-87s flying with 
                    //escorts, which is hte context here
                    bool isHeavyBomber = false;
                    if (acType.Contains("Ju-88") || acType.Contains("He-111") || acType.Contains("BR-20") || acType == ("BlenheimMkIV") || acType == ("Ju-87")) isHeavyBomber = true;
                    if (!isHeavyBomber) continue;
                    if (NearestAirgroup != null)
                    {
                        if (NearestAirgroup.Pos().distance(ref StartPos) > airGroup.Pos().distance(ref StartPos))
                            NearestAirgroup = airGroup;
                    }
                    else NearestAirgroup = airGroup;
                }
                return NearestAirgroup;
            }
            else
                return null;
        }
        catch (Exception ex) { Console.WriteLine("MoveBomb FriendlyBomber ERROR: " + ex.ToString()); return null; }

    }

    public AiAirGroup getNearestEnemyAirgroup(AiAirGroup from)
    {
        AiAirGroup NearestAirgroup = null;
        AiAirGroup[] EnemyAirgroups;
        Point3d StartPos = from.Pos();

        EnemyAirgroups = GamePlay.gpAirGroups((from.Army() == 1) ? 2 : 1);

        if (EnemyAirgroups != null)
        {
            foreach (AiAirGroup airgroup in EnemyAirgroups)
            {
                if (NearestAirgroup != null)
                {
                    if (NearestAirgroup.Pos().distance(ref StartPos) > airgroup.Pos().distance(ref StartPos))
                        NearestAirgroup = airgroup;
                }
                else NearestAirgroup = airgroup;
            }
            return NearestAirgroup;
        }
        else
            return null;

    }


    public double? getDistanceToNearestEnemyAirgroup(AiAirGroup from)
    {
        AiAirGroup NearestAirgroup = null;
        AiAirGroup[] EnemyAirgroups;
        Point3d StartPos = from.Pos();

        EnemyAirgroups = GamePlay.gpAirGroups((from.Army() == 1) ? 2 : 1);

        if (EnemyAirgroups != null)
        {
            foreach (AiAirGroup airgroup in EnemyAirgroups)
            {
                if (NearestAirgroup != null)
                {
                    if (NearestAirgroup.Pos().distance(ref StartPos) > airgroup.Pos().distance(ref StartPos))
                        NearestAirgroup = airgroup;
                }
                else NearestAirgroup = airgroup;
            }
            return NearestAirgroup.Pos().distance(ref StartPos);
        }
        else
            return null;
    }
    //Returns a point in/near the changed objective within the given radius OR
    //Null if the attack point is not within/near an airport OR no suitable airport found
    public Point3d? ChangeObjectives(Point3d p, int enemyArmy)
    {
        Point3d retPos;        

        var tup = RandomObjectiveWithin(p, enemyArmy, moveObjectivesDistance_m);
        if (!tup.Item1.HasValue) return null;
        
        int numEnemyPlayers = Calcs.gpNumberOfPlayersActive(GamePlay,  enemyArmy);

        retPos = tup.Item1.Value;
        double radius = tup.Item2;
        double dist_m = tup.Item3;
        if (numEnemyPlayers > 10) numEnemyPlayers = 10;

        //Mult & add will push target points further from the center of the objective with no or few enemy players online
        //and then bring it in close when there are a lot of enemy players
        double mult = (12.0 - (double)numEnemyPlayers) / 7.0;
        if (numEnemyPlayers == 0) mult = 20;
        if (mult < 0.5) mult = 0.5;

        double add = (6.0 - (double)numEnemyPlayers) / 6.0;
        if (add <= 0) add = 0;

        double dist = ran.NextDouble() * radius * mult + radius*add;
        double angl = ran.NextDouble() * 2 * Math.PI;

        //Console.WriteLine("MoveBomb: Position before # player adjustment {0:n0} {1:n0}", retPos.x, retPos.y);

        retPos.x = Math.Cos(angl) * dist + retPos.x;
        retPos.y = Math.Sin(angl) * dist + retPos.y;
        retPos.z = 0;


        //Console.WriteLine("MoveBomb: New OBJECTIVE attack point: {0:n0} {1:n0} {2:n0}", retPos.x, retPos.y, dist_m);
        return retPos;
    }

    //Returns an objective point & radius & distance that point p lies nearest.    
    private Tuple<Point3d?, double, double> NearestObjectivePoint (Point3d p, int army) //center point, radius, distance
    {
        double r = 10000000;
        Tuple<Point3d?, double, double> ret = new Tuple<Point3d?, double, double>(null, 0, r);

// *** Critical Game Flow Area ***
// This section manages mission events and interactions.
        foreach (string key in SMissionObjectivesList.Keys)
        {
            IMissionObjective mo = SMissionObjectivesList[key];
            if (mo.OwnerArmy != army) continue;
            double dist = Calcs.CalculatePointDistance(mo.Pos, p);
            if (dist <= r)
            {
                ret = new Tuple<Point3d?, double, double>(mo.Pos, mo.TriggerDestroyRadius, dist );
                r = dist;
                //Console.WriteLine("MBF: Best objective - " + mo.Name);
            }
        }
        return ret;
    }
    //Returns an objective point & radius & distance that point p lies nearest.    
    private Tuple<Point3d?, double, double> RandomObjectiveWithin(Point3d p, int army, double radius_m) //center point, radius, distance
    {

        Tuple<Point3d?, double, double> ret = new Tuple<Point3d?, double, double>(null, 0, 1000000);


// *** Critical Game Flow Area ***
// This section manages mission events and interactions.
        List<IMissionObjective> CloseObjectives = new List<IMissionObjective>();


// *** Critical Game Flow Area ***
// This section manages mission events and interactions.
        foreach (string key in SMissionObjectivesList.Keys)
        {
            IMissionObjective mo = SMissionObjectivesList[key];
            if (mo.OwnerArmy != army) continue;
            double dist = Calcs.CalculatePointDistance(mo.Pos, p);
            if (dist <= radius_m)
            {
                //ret = new Tuple<Point3d?, double, double>(mo.Pos, mo.TriggerDestroyRadius, dist);
                //r = dist;
                //Console.WriteLine("MBF: Best objective - " + mo.Name);
                CloseObjectives.Add(mo);
            }
        }

        int ind = 0;
        IMissionObjective retMO = null;
        if (CloseObjectives.Count > 0)
        {
            ind = ran.Next(CloseObjectives.Count - 1);
            retMO = CloseObjectives[ind];
            ret = new Tuple<Point3d?, double, double>(retMO.Pos, retMO.TriggerDestroyRadius, Calcs.CalculatePointDistance(retMO.Pos, p));
            //Console.WriteLine("MoveBomb: Chosen objective - " + retMO.Name);
        }
        return ret;
    }



    //Returns a point within the changed airport within the given radius OR
    //Null if the attack point is not within/near an airport OR no suitable airport found
    public Point3d? ChangeAirports(Point3d p, int airportArmy)
    {
        Point3d retPos;

        AiAirport nearestAirfield = GetAirfieldAt(p);

        //check whether the attack point is within or very near an airfield
        //if (nearestAirfield.Pos().distance(ref p) > nearestAirfield.FieldR() * 1.25)
        if (Calcs.CalculatePointDistance(nearestAirfield.Pos(), p) > 2000) //The GATTACK_POINT distance is often quite far from the target itself
        {
            //Console.WriteLine("MoveBomb: Attack point NOT within an airfield {0:n0} {1:n0} {2:n0} {3:n0} {4:n0}", nearestAirfield.Pos().x, nearestAirfield.Pos().y, p.x, p.y, Calcs.CalculatePointDistance(nearestAirfield.Pos(), p));
            return null;
        }


        //Get the random airport within the given radius
        AiAirport ap = GetRandomAirfieldNear(p, moveAirportsDistance_m, airportArmy);

        //Console.WriteLine("MoveBomb: Attack point IS within an airfield {0:n0} {1:n0} {2:n0} {3:n0} {4:n0} {5} to {6}", nearestAirfield.Pos().x, nearestAirfield.Pos().y, p.x, p.y, Calcs.CalculatePointDistance(nearestAirfield.Pos(), p), nearestAirfield.Name(), ap.Name());

        if (ap != null)
        {

            //Choose a random point within the airfield radius
            double radius = ap.FieldR();
            Point3d center = ap.Pos();
            double dist = ran.NextDouble() * radius / 2;
            double angl = ran.NextDouble() * 2 * Math.PI;

            int numEnemyPlayers = Calcs.gpNumberOfPlayersActive(GamePlay, airportArmy);

            if (numEnemyPlayers > 10) numEnemyPlayers = 10;

            //Mult & add will push target points further from the center of the objective with no or few enemy players online
            //and then bring it in close when there are a lot of enemy players
            double mult = (12.0 - (double)numEnemyPlayers) / 7.0;
            if (numEnemyPlayers == 0) mult = 20;
            if (mult < 0.5) mult = 0.5;

            double add = (6.0 - (double)numEnemyPlayers) / 4.0;
            if (add <= 0) add = 0;

            dist = ran.NextDouble() * radius * mult + radius * add;

            retPos.x = Math.Cos(angl) * dist + center.x;
            retPos.y = Math.Sin(angl) * dist + center.y;
            retPos.z = 0;

            //return the SAME relative position to this new airfield as we had with the old airfield
            //This is important because the attack point is often quite distant from the airfield itself, in order to actually hit the airfield accurately
            //retPos.x = p.x - nearestAirfield.Pos().x + ap.Pos().x;
            //retPos.y = p.y - nearestAirfield.Pos().y + ap.Pos().y;

            //Ok, we're going to make the airport attacks more effective by just centering them more on the new airport (plus/minus the radius defined above, of course)
            //With Tobruk_Campaign 3.0 this looks to be TOO accurate now, we'll go back to kinda inaccurate
            /*
            retPos.x = ap.Pos().x;
            retPos.y = ap.Pos().y;
            retPos.z = 0;
            */
            Console.WriteLine("MoveBomb: New attack point: {0:n0} {1:n0} {2:n0} {3:n0} {4:n0} {5} to {6}", ap.Pos().x, ap.Pos().y, retPos.x, retPos.y, Calcs.CalculatePointDistance(ap.Pos(), retPos), nearestAirfield.Name(), ap.Name());
            return retPos;
        }
        else return null;

    }

    //return a point that is within the map coordinates.  Selecting any points & then correcting it to within the coordinates gives undue weight to points
    //near the edge of the map so lets just pick a random point within the radius & on the  map, without any undue weight to edges
    //XY_m is the large/major correction whereas aimXY_m is a small additional correction of the precise aim.
    public Point3d safePointSelect(Point3d pos, double XY_m, double aimXY_m)
    {
        double offMapBufferForAvoidingLeaveMap = -1000; //Max off map amount to allow as part of a normal flight plan
        Point3d NewPos = pos;
        for (int i = 0; i < 100; i++)
        {
            NewPos = pos;
            double XY = XY_m + aimXY_m;
            NewPos.x += ran.NextDouble() * 2 * XY - XY;
            NewPos.y += ran.NextDouble() * 2 * XY - XY;
            if (NewPos.x > twcmap_maxX + offMapBufferForAvoidingLeaveMap || NewPos.y > twcmap_maxY + offMapBufferForAvoidingLeaveMap || NewPos.x < twcmap_minX - offMapBufferForAvoidingLeaveMap || NewPos.y < twcmap_minY - offMapBufferForAvoidingLeaveMap) continue;
            return NewPos;            
        }
        return NewPos;

    }

    public bool isTobrukAttackBombers (AiAirGroup airGroup)
    {
        bool isTobrukAttackBomber = false;

        if ((airGroup as AiActor != null) &&
              (
                ((AiActor)airGroup).Name().Contains("BoB_RAF_B_7Sqn") || ((AiActor)airGroup).Name().Contains("Tobruk_LW_JG3_II")
              )
           ) //these are the 2 airgroup names we're using in the BuildBomb routine
        {
            Console.WriteLine("This is a Tobruk bomber, exiting MoveBomb (group name matches)");
            return true; //It's an airport & a high-value primary target so just bail.
        }

        AiWayPoint[] CurrentWaypoints = airGroup.GetWay();

        foreach (AiWayPoint wp in CurrentWaypoints)
        {
            Point3d pos = (wp as AiAirWayPoint).P;
            //TOBRUK: IF this is targeting an objective airport (would be the bumrush target in Tobruk)
            //We just skip changing these waypoints altogether.
            if ((wp as AiAirWayPoint).Action == AiAirWayPointType.GATTACK_POINT)
            {

// *** Critical Game Flow Area ***
// This section manages mission events and interactions.
                foreach (string key in SMissionObjectivesList.Keys)
                {
                    IMissionObjective mo = SMissionObjectivesList[key];
                    //if (!mo.IsEnabled || !mo.IsPrimaryTarget || mo.Points < 10) continue;
                    if (mo.Points < 10) continue;
                    if (Calcs.CalculatePointDistance(pos, mo.Pos) > 3500) continue;
                    Console.WriteLine("This is a Tobruk bomber, exiting MoveBomb (attacking Tobruk Primary Objective/airport)");
                    return true; //It's an airport & a high-value primary target so just bail.
                }
            }

            if ((wp as AiAirWayPoint).Action == AiAirWayPointType.GATTACK_TARG)
            {
                //So . . . due to Tobruk programming, if the aigroup is targeted at a CHIEF (which is like a moving ship, train, ground convoy etc) then we will 
                //skip retargeting from this.  UNLESS there are more then X players online, then we will retarget.
                if ((wp as AiAirWayPoint).Target != null)
                {
                    AiActor aia = (wp as AiAirWayPoint).Target;
                    AiAIChief aiaChief = aia as AiAIChief;
                    if (aiaChief != null)
                    {
                        Console.WriteLine("This is a Tobruk bomber, exiting MoveBomb (AiChief)");
                        return true;
                    }
                    
                }

            }
        }
        return false;

    }

    public bool updateAirWaypoints(AiAirGroup airGroup)
    {
        try
        {
            if (airGroup == null || airGroup.GetWay() == null || !isAiControlledAirGroup(airGroup)) return false;
            if (ran.Next(10) == 1)
            {
                fixWayPoints(airGroup); //fix any problems, particularly add the two endpoints that will take the a/c off the map @ the end
                return false; //Just leave it as originally written sometimes
            }

            AiWayPoint[] CurrentWaypoints = airGroup.GetWay();

            //for testing
            foreach (AiWayPoint wp in CurrentWaypoints)
            {
                AiWayPoint nextWP = wp;
                //Console.WriteLine("Target before: {0} {1:n0} {2:n0} {3:n0} {4:n0}", new object[] { (wp as AiAirWayPoint).Action, (wp as AiAirWayPoint).Speed, wp.P.x, wp.P.y, wp.P.z });

            }

            int currWay = airGroup.GetCurrentWayPoint();
            double speedDiff = 0;
            double altDiff_m = 0;

            //Console.WriteLine("MBTITG: 2");
            //if (currWay< CurrentWaypoints.Length) Console.WriteLine( "WP: {0}", new object[] { CurrentWaypoints[currWay] });
            //if (currWay < CurrentWaypoints.Length) Console.WriteLine( "WP: {0}", new object[] { CurrentWaypoints[currWay].Speed });
            //if (currWay < CurrentWaypoints.Length) Console.WriteLine( "WP: {0}", new object[] { (CurrentWaypoints[currWay] as AiAirWayPoint).Action });

            List<AiWayPoint> NewWaypoints = new List<AiWayPoint>();
            int count = 0;
            //Console.WriteLine("MBTITG: 3");

            int army = airGroup.getArmy();
            int enemyArmy = 3 - army;

            int numFriendlyPlayers = Calcs.gpNumberOfPlayersActive(GamePlay, army);
            int numEnemyPlayers = Calcs.gpNumberOfPlayersActive(GamePlay, enemyArmy);

            //if fewer than 5 friendly players then we leave all friendly AC alone.  If more than 5 we phase them out until 0 left when 20 friendly players in
            bool eliminateThisAIAircraft = false;
            
            if (numFriendlyPlayers>5)
            {
                double pctAIAircraftToEliminate = 0;

                pctAIAircraftToEliminate = ((double)numFriendlyPlayers - 5.0) / 15.0;
                if (ran.NextDouble() < pctAIAircraftToEliminate) eliminateThisAIAircraft = true;
            }

            bool isBomber = Calcs.isHeavyBomber(airGroup) || Calcs.isDiveBomber(airGroup);

            bool underRadar = false;
            if (isBomber && ran.Next(0, 10) == 0) underRadar = true;
            //Console.WriteLine("Movebomb: Under radar: {0}", underRadar);

            bool update = false;
            AiWayPoint wpAdd = CurrentPosWaypoint(airGroup, (CurrentWaypoints[currWay] as AiAirWayPoint).Action);

            if (wpAdd != null) NewWaypoints.Add(wpAdd); //Always have to add current pos/speed as first point or things go w-r-o-n-g



            foreach (AiWayPoint wp in CurrentWaypoints)
            {
                try
                {
                    AiWayPoint nextWP = wp;
                    //Console.WriteLine( "Target: {0}", new object[] { wp });
// Added null check to prevent crashes.
                    if (wp == null || object == null || (wp as AiAirWayPoint) == null || object == null) continue;

// Added null check to prevent crashes.
                    if ((wp as AiAirWayPoint).Action == null || object == null) return false;

                    //So for aircraft we are "eliminating" for example if there are a lot of people in the server & so we're just diverating all AI to land or ooff the map,
                    //We do this by just eliminating all their waypoints EXCEPT landing.
                    if (eliminateThisAIAircraft && (wp as AiAirWayPoint).Action != AiAirWayPointType.LANDING) continue;

                    Point3d? newAirportPosition = wp.P as Point3d?;
                    Point3d? newObjectivePosition = wp.P as Point3d?;

                    if (moveAirports && ((wp as AiAirWayPoint).Action == AiAirWayPointType.GATTACK_TARG || (wp as AiAirWayPoint).Action == AiAirWayPointType.GATTACK_POINT))
                    { newAirportPosition = ChangeAirports(wp.P, enemyArmy); }

                    if (attackObjectives && ((wp as AiAirWayPoint).Action == AiAirWayPointType.GATTACK_TARG || (wp as AiAirWayPoint).Action == AiAirWayPointType.GATTACK_POINT))
                    { newObjectivePosition = ChangeObjectives(wp.P, enemyArmy); }

                    changeLimit changeL = new changeLimit();
                    if (changeLimits.ContainsKey((wp as AiAirWayPoint).Action))
                    {
                        Point3d pos;
                        double speed;

                        changeL = changeLimits[(wp as AiAirWayPoint).Action];
                        if (count == 1 && (isBomber)) //for heavy/dive bombers the 2nd waypoint is more of a dogleg than a giant cross-map trip.
                        {
                            changeL.XY_m = changeL.XY_m / 4;
                        }

                        //TODO: We could have higher/lower altitude & speed apply to the entire mission for this airgroup rather than varying waypoint by waypoing. 
                        //that might be a more sensible approach

                        switch ((wp as AiAirWayPoint).Action)
                        {
                            /*case AiAirWayPointType.GATTACK_POINT:
                                //Console.WriteLine( "Updating, current TASK: {0}", new object[] { airGroup.getTask() });
                                //Console.WriteLine( "Target before: {0}", new object[] { (wp as AiAirWayPoint).Action });
                                pos = wp.P;                        
                                speed = wp.Speed;
                                pos.x += ran.NextDouble() * 2 * changeL.XY_m - changeL.XY_m;
                                pos.y += ran.NextDouble() * 2 * changeL.XY_m - changeL.XY_m;
                                speed += speed * (ran.NextDouble() * 2 * changeL.speed_percent/100 - changeL.speed_percent / 100);
                                //don't change the altitude/pos.z for GATTACK_POINT type (it should generally be on the ground anyway?  There could be problems if our attack point is too far above or below the ground maybe?  If so we might need to specify ground level for our chosen x,y point?)
                                //Update: actually the pos.z of the GATTACK_POINT is the altitude of the bombers when attacking, not the altitude of the point to attack
                                //So, we can treat this exactly like all the other task types                      
                                nextWP = new AiAirWayPoint(ref pos, speed);
                                (nextWP as AiAirWayPoint).Action = (wp as AiAirWayPoint).Action;
                                //Console.WriteLine( "Target after: {0}", new object[] { wp });
                                //Console.WriteLine( "Added{0}: {1}", new object[] { count, nextWP.Speed });
                                //Console.WriteLine( "Added: {0}", new object[] { (nextWP as AiAirWayPoint).Action });
                                update = true;
                                break;
                                */
                            case AiAirWayPointType.GATTACK_TARG:
                                //Console.WriteLine( "Updating, current TASK: {0}", new object[] { airGroup.getTask() });
                                //Console.WriteLine( "Target before: {0}", new object[] { (wp as AiAirWayPoint).Action });
                                


                                pos = wp.P;
                                if (newAirportPosition.HasValue)
                                {
                                    Console.WriteLine("MoveBomb: Moving to attack an airport! {0:F0} {1:F0}", wp.P.x, wp.P.y);
                                    pos = newAirportPosition.Value;
                                    pos.z = wp.P.z;
                                }
                                else if (newObjectivePosition.HasValue)
                                {
                                    Console.WriteLine("MoveBomb: Moving to attack an objective! {0:F0} {1:F0}", wp.P.x, wp.P.y);
                                    pos = newObjectivePosition.Value;
                                    pos.z = wp.P.z;

                                }

                                if (speedDiff == 0) speedDiff = wp.Speed * (ran.NextDouble() * 2.0 * changeL.speed_percent / 100.0 - changeL.speed_percent / 100);
                                speed = wp.Speed + speedDiff;
                                //pos.x += ran.NextDouble() * 2 * changeL.XY_m - changeL.XY_m;
                                //pos.y += ran.NextDouble() * 2 * changeL.XY_m - changeL.XY_m;

                                //so, (wp as AiAirWayPoint).Target; is NULL for SOME REASON, even though the groundactor to attack is set in the .mis file
                                //AiActor currTarget = (wp as AiAirWayPoint).Target;
                                /*
// Added null check to prevent crashes.
                                if (currTarget == null || object == null)
                                {
                                    Console.WriteLine("MoveBomb: Target is NULL!! Breaking");
                                    Console.WriteLine("MoveBomb: {0} {1} {2} {3}", (wp as AiAirWayPoint).Action, (wp as AiAirWayPoint).Target.Name(), (wp as AiAirWayPoint).GAttackPasses, (wp as AiAirWayPoint).GAttackType);

                                    AiActor[] acts = airGroup.GetItems();
                                    foreach (AiActor act in acts)
                                    {
                                        Console.WriteLine("MoveBomb: {0}", act.Name());
                                    }
                                    break;
                                }
                                */

                                GroundStationary newTarget = null;
                                //Choose another ground stationary somewhere within the given radius of change, starting with the GATTACK point since we don't have an actual GATTACK target actor; make sure it is alive if possible
                                GroundStationary[] stationaries = GamePlay.gpGroundStationarys(pos.x, pos.y, changeL.XY_m);
                                //Console.WriteLine("MoveBomb: Looking for nearby stationary");
                                for (int i = 1; i < 20; i++)
                                {

                                    if (stationaries.Length == 0) break;
                                    int newStaIndex = ran.Next(stationaries.Length - 1);
                                    if (stationaries[newStaIndex] != null && stationaries[newStaIndex].IsAlive &&
                                        (stationaries[newStaIndex].pos.x != pos.x ||
                                        stationaries[newStaIndex].pos.y != pos.y)
                                        && GamePlay.gpFrontArmy(stationaries[newStaIndex].pos.x, stationaries[newStaIndex].pos.y) == enemyArmy)
                                    {
                                        newTarget = stationaries[newStaIndex];
                                        //Console.WriteLine("MoveBomb: FOUND a stationary");
                                        break;
                                    }
                                }
                                //In case we didn't find a ground target there, expand the search radius a bit & try again
// Added null check to prevent crashes.
                                if (newTarget == null || object == null)
                                {
                                    //Console.WriteLine("MoveBomb: Looking for further afield stationaries");
                                    GroundStationary[] stationaries2 = GamePlay.gpGroundStationarys(pos.x, pos.y, 3 * changeL.XY_m);
                                    for (int i = 1; i < 20; i++)
                                    {
                                        if (stationaries2.Length == 0) break;
                                        int newStaIndex = ran.Next(stationaries2.Length - 1);
                                        if (stationaries2[newStaIndex] != null && stationaries2[newStaIndex].IsAlive &&
                                        (stationaries2[newStaIndex].pos.x != pos.x ||
                                        stationaries2[newStaIndex].pos.y != pos.y))
                                        {
                                            newTarget = stationaries2[newStaIndex];
                                            break;
                                        }
                                    }
                                }

                                Point3d newPos = pos;
                                //Use the position of the newly found ground actor as the new attack position, IF the actor exists/was found
                                if (newTarget != null)
                                {
                                    //Console.WriteLine("MoveBomb: Found a stationary, updating attack position");
                                    newPos.x = newTarget.pos.x;
                                    newPos.y = newTarget.pos.y;
                                }
                                //3rd approach, just move the attack point by our usual amount
                                else
                                {
                                    //Console.WriteLine("MoveBomb: No stationary found, updating attack position");
                                    newPos = safePointSelect(pos, changeL.XY_m, changeL.aimXY_m);

                                }

                                newPos.z += altDiff_m;


                                nextWP = new AiAirWayPoint(ref newPos, speed);
                                (nextWP as AiAirWayPoint).Action = (wp as AiAirWayPoint).Action;  //keep action same
                                (nextWP as AiAirWayPoint).GAttackPasses = (wp as AiAirWayPoint).GAttackPasses;  //keep # passes the same.  TODO: could change this in some reasonable but random way.
                                (nextWP as AiAirWayPoint).GAttackType = (wp as AiAirWayPoint).GAttackType;  //keep attack type the same. TODO: could change this randomly

                                if ((newTarget as AiActor) != null) (nextWP as AiAirWayPoint).Target = newTarget as AiActor;  //change to newly selected target
                                                                                                                              //Console.WriteLine( "Target after: {0}", new object[] { wp });
                                                                                                                              //Console.WriteLine( "Added{0}: {1}", new object[] { count, nextWP.Speed });
                                string nm = "(null)";
                                //if (((wp as AiAirWayPoint).Target as AiActor) != null) nm = ((wp as AiAirWayPoint).Target as AiActor).Name(); //doesn't work bec. grounstationaries are never AiActors.  We could try looking for AiGroundActors AiGroundGroups, or even AirGroups instead, maybe.  
                                //Console.WriteLine("Old Ground Target: {0} {1} {2:n0} {3:n0} {4} {5}", new object[] { (wp as AiAirWayPoint).Action, nm, (wp as AiAirWayPoint).P.x, (wp as AiAirWayPoint).P.y, (wp as AiAirWayPoint).GAttackPasses, (wp as AiAirWayPoint).GAttackType });
                                //Console.WriteLine ("New Ground Target: {0} {1} {2:n0} {3:n0} {4} {5}", new object[] { (wp as AiAirWayPoint).Action, nm, (nextWP as AiAirWayPoint).P.x, (nextWP as AiAirWayPoint).P.y, (nextWP as AiAirWayPoint).GAttackPasses, (nextWP as AiAirWayPoint).GAttackType });
                                /* Console.WriteLine( "New Ground Target: {0} {1} {2:n0} {3:n0} {4} {5}", new object[] { (nextWP as AiAirWayPoint).Action, (nextWP as AiAirWayPoint).Target.Name(), (nextWP as AiAirWayPoint).Target.Pos().x, (nextWP as AiAirWayPoint).Target.Pos().y, (nextWP as AiAirWayPoint).GAttackPasses, (nextWP as AiAirWayPoint).GAttackType }); */

                                update = true;
                                break;
                            case AiAirWayPointType.GATTACK_POINT:
                            case AiAirWayPointType.HUNTING:
                            case AiAirWayPointType.NORMFLY:
                            case AiAirWayPointType.RECON:
                            case AiAirWayPointType.AATTACK_FIGHTERS:
                            case AiAirWayPointType.AATTACK_BOMBERS:
                                //Console.WriteLine( "Updating, current TASK: {0}", new object[] { airGroup.getTask() });
                                //Console.WriteLine( "Target before: {0}", new object[] { (wp as AiAirWayPoint).Action });
                                pos = wp.P;

                                //Console.WriteLine("Movebomb - Target before: {0:F0} {1:F0} {2:F0}", pos.x, pos.y, pos.z);

                                //GetRandomAirfieldNear(p, moveAirportsDistance_m, airportArmy);

                                //Add first "airfield switch" for bomber groups, most of the time.  They fly low/under radar to some relatively nearby airport, making it appear as though they are starting
                                //at different airports, not just at the one spot where they spawn in.
                                if (count == 0 && currWay >= count && isBomber && (wp as AiAirWayPoint).Action == AiAirWayPointType.NORMFLY && ran.Next(4) > 0)
                                {
                                    double airportChange_m = 25000;
                                    AiAirport ap = GetRandomAirfieldNear(pos, airportChange_m, army);
                                    Point3d airportPos = ap.Pos();
                                    airportPos.z = airportPos.z + 200;
                                    AiAirWayPoint airportWP = new AiAirWayPoint(ref airportPos, wp.Speed);
                                    (airportWP as AiAirWayPoint).Action = (wp as AiAirWayPoint).Action;
                                    NewWaypoints.Add(airportWP);
                                }

                                //Add first extra waypoint that's just a little jog, for bomber groups
                                if (count == 0 && currWay >= count && isBomber && (wp as AiAirWayPoint).Action == AiAirWayPointType.NORMFLY)
                                {
                                    double firstChange = changeL.XY_m / 10;
                                    Point3d firstPos = safePointSelect(pos, firstChange, 0);
                                    AiAirWayPoint firstWP = new AiAirWayPoint(ref firstPos, wp.Speed);
                                    (firstWP as AiAirWayPoint).Action = (wp as AiAirWayPoint).Action;
                                    NewWaypoints.Add(firstWP);
                                }



                                if ((wp as AiAirWayPoint).Action == AiAirWayPointType.GATTACK_POINT && newAirportPosition.HasValue)
                                {
                                    //Console.WriteLine("MoveBomb: Moving airport of attack!");
                                    Console.WriteLine("MoveBomb: Moving to attack an airport! {0:F0} {1:F0}", wp.P.x, wp.P.y);
                                    pos = safePointSelect(newAirportPosition.Value, 0, changeL.aimXY_m);
                                    pos.z = wp.P.z;
                                }
                                else if ((wp as AiAirWayPoint).Action == AiAirWayPointType.GATTACK_POINT && newObjectivePosition.HasValue)
                                {
                                    Console.WriteLine("MoveBomb: Moving to attack an objective! {0:F0} {1:F0}", wp.P.x, wp.P.y);
                                    pos = safePointSelect(newObjectivePosition.Value, 0, changeL.aimXY_m);
                                    pos.z = wp.P.z;

                                }
                                else
                                {
                                    pos = safePointSelect(pos, changeL.XY_m, 0);
                                    pos.z = wp.P.z;
                                }

                                speed = wp.Speed;

                                if (speedDiff == 0) speedDiff = speed * (ran.NextDouble() * 2 * changeL.speed_percent / 100 - changeL.speed_percent / 100);
                                //Note that bombers can outrun their cover aircraft here if we're not careful.  For now we're dealing by making cover a/c go a fair bit faster than their bombers in the .mis file
                                //We're adjusting bomber speed here but NOT cover a/c speed (ESCORT)
                                if (isBomber && speedDiff > .08 * speed) speedDiff = .08 * speed; //limit bomber speed increase, so they don't ditch their escorts
                                speed += speedDiff;
                                double zSave = pos.z;

                                //Keep the same delta altitude, unless it hasn't been set yet OR it is too low
                                if (altDiff_m == 0 || zSave * (1 - changeL.alt_percent / 100) > zSave + altDiff_m)
                                {

                                    //Figure alt change by both the absolute (meters) and percent method, then pick which to use
                                    double zChangeAbs = ran.NextDouble() * 2.0 * changeL.alt_m - changeL.alt_m;
                                    double zChangePerc = zSave * (ran.NextDouble() * 2.0 * changeL.alt_percent / 100.0 - changeL.alt_percent / 100.0);
                                    double zChangeFinal = zChangeAbs;
                                    if (changeL.alt_percent / 100.0 * zSave > changeL.alt_m) zChangeFinal = zChangePerc;  //if (potential max) perc change is larger then abs change then we go with perc change
                                    if (zSave * (1 - changeL.alt_percent / 100) > zChangeAbs) zChangeFinal = zChangePerc; //if actual abs change is less than min possible perc change than we go with perc change (to prevent setting altitude unreasonably low)
                                    altDiff_m = zChangeFinal;
                                }

                                pos.z += altDiff_m;

                                //if (zSave<changeL.alt_m && pos.z < zSave) pos.z = zSave;  //
                                if (pos.z < 100 && pos.z < zSave) pos.z = 100; //Never altitude less than 100m, unless the pre-set alt was less than 100m & this is equal to or greater than the previous set altitude                        
                                                                               //Console.WriteLine("Target after: {0:F0} {1:F0} {2:F0}", pos.x, pos.y, pos.z);

                                nextWP = new AiAirWayPoint(ref pos, speed);
                                (nextWP as AiAirWayPoint).Action = (wp as AiAirWayPoint).Action;
                                //Console.WriteLine( "Target after: {0}", new object[] { nextWP });
                                //Console.WriteLine( "Added{0}: {1}", new object[] { count, nextWP.Speed });
                                //Console.WriteLine( "Added: {0}", new object[] { (nextWP as AiAirWayPoint).Action });
                                update = true;
                                break;


                        }
                        if (underRadar)
                        {
                            //AI get a break of 600ft altitude for staying-below-radar purposes.  soo 800-900 ft or below is off radar.
                            //There isn't much point in sending AI missions that are COMPLETELY off radar as no one will even know about them.  But if we keep them at the alt where they will 
                            //kind of phase in/out of radar that would be ideal.
                            nextWP.P.z = 375 + altDiff_m / 10;
                            if (nextWP.P.z < 300) nextWP.P.z = 300; //275m is about 900 ft alt = 300ft for breathers = still mostly off radar when over water (and probably right off it over land. where AGL will be lower).
                            update = true;
                        }
                    }



                    if (count >= currWay)
                    {
                        NewWaypoints.Add(nextWP);

                        /*
                        if (update)
                        {
                            Console.WriteLine( "Added{0}: {1}", new object[] { count, nextWP.Speed });
                            Console.WriteLine( "Added: {0}", new object[] { (nextWP as AiAirWayPoint).Action });
                        }
                        */

                    }

                    //Console.WriteLine("MBTITG: 4");
                    count++;
                }
                catch (Exception ex) { Console.WriteLine("MoveBomb CurrentPosWaypointLOOP ERROR: " + ex.ToString()); }

            }

            foreach (AiWayPoint wp in NewWaypoints)
            {
                AiWayPoint nextWP = wp;
                //Console.WriteLine( "Target after: {0} {1:n0} {2:n0} {3:n0} {4:n0}", new object[] { (wp as AiAirWayPoint).Action, (wp as AiAirWayPoint).Speed, wp.P.x, wp.P.y, wp.P.z });

            }


            //NewWaypoints.Add(CurrentPosWaypoint(airGroup));
            //NewWaypoints.AddRange(SetWaypointBetween(airGroup.Pos(), AirGroupAirfield.Pos(), 4000, 90.0));
            //NewWaypoints.Add(GetLandingWaypoint(AirGroupAirfield, 1000.0));


            if (update)
            {
                //Console.WriteLine("MBTITG: Updating this course");
                Timeout(ran.NextDouble() * 10, () =>
                {
                    airGroup.SetWay(NewWaypoints.ToArray());
                    fixWayPoints(airGroup); //fix any problems that might have resulted from the new waypoint fixes.
                });
                return true;
            }
            else
            { return false; }

        }

        catch (Exception ex) { Console.WriteLine("MoveBomb UpdateWaypoint: " + ex.ToString()); return false; }
    }

    public bool playersNearby(AiAirGroup airGroup, double dist_m = 14000)
    {
        Tuple<double, double> dist = getDistanceToNearestLivePilot(airGroup);
// Added null check to prevent crashes.
        //Console.WriteLine("MoveBomb: Players nearby {0} {1} ", dist.Item1 == null || object == null, (double)(dist.Item1));
        if (dist.Item1 == -1 || (double)(dist.Item1) > dist_m) return false; //no players nearby, at least 10km away  OR the airGroup doesn't even exist, whatever
        return true; //Players nearby
    }

    //So setting AI airgroups to LANDING is our clue that we are free to despawn them at any time. We first check there
    //are no live players nearby to see the despawn
    public void checkToDespawnOldAirgroups(AiAirGroup airGroup) {
        try
        {
// Added null check to prevent crashes.
            if (airGroup == null || object == null) return;
            Console.WriteLine("MoveBomb: Checking AI airgroups whose mission is complete with task LANDING: " + airGroup.Name());
            //!AirgroupsWayPointProcessed.Contains(airGroup), airGroup.GetItems().Length == 0, !isAiControlledPlane2(airGroup.GetItems()[0] as AiAircraft));
            if (airGroup == null || !AirgroupsWayPointProcessed.Contains(airGroup) || airGroup.GetItems() == null || airGroup.GetItems().Length == 0 || !isAiControlledPlane2(airGroup.GetItems()[0] as AiAircraft)) return; //only process groups that have been in place a while, have actual aircraft in the air, and ARE ai
            AiAirGroupTask task = airGroup.getTask();
            AiWayPoint[] CurrentWaypoints = airGroup.GetWay();
            int currWay = airGroup.GetCurrentWayPoint();
            bool landingWaypoint = false;
            
            if (CurrentWaypoints != null && CurrentWaypoints.Length > 0 && CurrentWaypoints.Length > currWay && (CurrentWaypoints[currWay] as AiAirWayPoint).Action == AiAirWayPointType.LANDING) landingWaypoint = true;

            if (task != AiAirGroupTask.LANDING || !landingWaypoint) return; //Task LANDING is our clue these are ready to get out of here, accepting EITHER task landing OR LANDING is current Waypoint action caused trouble (because waypoing "landing" can be set many hundreds of miles from the actual landing spot), so we require BOTH of these set to LANDING before actually disapparating them.
            //if (!landingWaypoint) return; //Task LANDING is our clue these are ready to get out of here, loosening this up to try to get rid of useless/finished airgroups more quickly.
            Console.WriteLine("MoveBomb: Checking AI  groups for removal (task LANDING) {0} {1} {2} {3} players nearby: {4} ", CurrentWaypoints.Length, currWay, (CurrentWaypoints[currWay] as AiAirWayPoint).Action, task, (playersNearby(airGroup)));

            if (playersNearby(airGroup, 16000)) return; //Don't dis-apparate them if there are any players nearby to see it happen

            double airportDistance_m = DistanceToNearestAirport(airGroup as AiActor);

            if (airportDistance_m > 8000) return;

            if (GamePlay.gpFrontArmy(airGroup.Pos().x, airGroup.Pos().y) != airGroup.getArmy()) return;

// Added null check to prevent crashes.
            if (airGroup == null || object == null) return;

            List<AiActor> items = new List<AiActor>(airGroup.GetItems());

            Point3d pos = airGroup.Pos();

            foreach (AiActor actor in items)
            {
                AiAircraft aircraft = actor as AiAircraft;
                double altAGL_m = aircraft.getParameter(part.ParameterTypes.Z_AltitudeAGL, 0); // Z_AltitudeAGL is in meters
                if (altAGL_m > 800) continue; //only dis-apparate if they are somewhat close to ground and "landing".  They hover at about 2000 ft AGL while waiting to land
                Console.WriteLine("MoveBomb: Destroying AI group item with mission complete & task&waypoint LANDING: " + actor.Name() + " " + aircraft.TypedName() + " ");
                if (Calcs.CalculatePointDistance(aircraft.Pos(), pos) > 6000) continue; //don't disapparate if it's too far from the main group.  It MIGHT be near a person or whatever
                if (aircraft != null && isAiControlledPlane2(aircraft)) Timeout(1, ()=> aircraft.Destroy()); //trying timeout as a way to get around changing/deleting the items on the list while stepping through the list.
            }
            //Console.WriteLine("MoveBomb: Checking {0} {1} {2} {3} {4} {5:N0}", CurrentWaypoints.Length, currWay, (CurrentWaypoints[currWay] as AiAirWayPoint).Action, task, (playersNearby(airGroup)), airportDistance_m);
        }
        catch (Exception ex) { Console.WriteLine("MoveBomb Check LANDING ERROR: " + ex.ToString()); }
    }
    public void printAirgroupNames(AiAirGroup[] airGroups)
    {
        foreach (AiAirGroup airGroup in airGroups)
        {
            Console.Write(airGroup.Name() + " ");
        }
// Removed empty Console.WriteLine(); to optimize performance.
    }

    public void printAttachedAirgroups(AiAirGroup airGroup)
    {
        /*
         * So, airgroups that are ie escorting bombers have task "defending".  The airgroup they are defending is the "client"
         * 
         * Task RETURN *might* mean that the escorts are returning to their client group.  Not 100% sure however.
         * 
         * If airgroups split up, say when landing (or maybe other situations?) then the new split-off airgroup has motherGroup() set to the original group it split off from.
         * 
         * Airgroups that are attacking some aircraft are "ATTACK_AIR".  There doesn't seem to be the target of the attack available anyway.
         * 
         * enemies, candidates, mothergroups, daughtergroups, attachedgroups I haven't found used at all, yet.
         * 
         * 
         * */
        try
        {
            if (airGroup == null || !AirgroupsWayPointProcessed.Contains(airGroup) || airGroup.GetItems().Length == 0 || !isAiControlledPlane2(airGroup.GetItems()[0] as AiAircraft)) return; //only process groups that have been in place a while, have actual aircraft in the air, and ARE ai
            AiAirGroupTask task = airGroup.getTask();
            Console.WriteLine("Airgroup {0} info & attached groups: {1}", airGroup.Name(), task);
            
            if (airGroup.clientGroup() != null) Console.WriteLine("client: {0}", airGroup.clientGroup().Name());
            if (airGroup.leaderGroup() != null) Console.WriteLine("leader: {0}", airGroup.leaderGroup().Name());
            if (airGroup.motherGroup() != null) Console.WriteLine("mother: {0}", airGroup.motherGroup().Name());

            if (airGroup.attachedGroups().Length > 0)
            {
                Console.WriteLine("Attached groups");
                printAirgroupNames(airGroup.attachedGroups());
            }
            
            if (airGroup.candidates().Length > 0)
            { 
                Console.WriteLine("Candidates");
                printAirgroupNames(airGroup.candidates());
            }
            if (airGroup.enemies().Length > 0)
            {
                Console.WriteLine("Enemies");
                printAirgroupNames(airGroup.enemies());
            }
            
            if (airGroup.daughterGroups().Length > 0)
            {
                Console.WriteLine("Daughter groups");
                printAirgroupNames(airGroup.daughterGroups());
            }
            
        }
        catch (Exception ex) { Console.WriteLine("MoveBomb print groups ERROR: " + ex.ToString()); }


    }



    public void checkNewAirgroups()
    {
         
        GetCurrentAiAirgroups();
        foreach (AiAirGroup airGroup in airGroups)
        {
            try
            {
                //printAttachedAirgroups(airGroup); //for testing
                checkToDespawnOldAirgroups(airGroup);
// Added null check to prevent crashes.
                if (airGroup == null || object == null) continue;
                if (AirgroupsWayPointProcessed.Contains(airGroup)) continue;

                AirgroupsWayPointProcessed.Add(airGroup);

                if (isTobrukAttackBombers(airGroup)) continue;

                if (airGroup.GetItems().Length == 0 || !isAiControlledPlane2(airGroup.GetItems()[0] as AiAircraft)) continue;

                updateAirWaypoints(airGroup);
            }
            catch (Exception ex) { Console.WriteLine("MoveBomb checkNewAirgroups() ERROR: " + ex.ToString()); }
        }
    }


    public void checkAirgroupsIntercept_recur()
    {
        /************************************************
         * 
         * Change airgroups to intercept nearest interesting enemy
         * Recursive function called every X seconds
         ************************************************/

        Timeout(187, () => { checkAirgroupsIntercept_recur(); });
        if (TWCComms.Communicator.Instance.WARP_CHECK) Console.WriteLine("MBTXX1 " + DateTime.UtcNow.ToString("T")); //Testing for potential causes of warping

        //Timeout(27, () => { checkAirgroupsIntercept_recur(); }); //for testing

        Task.Run(() => checkAirgroupsIntercept());
        //checkAirgroupsIntercept();
    }

    public void checkAirgroupsIntercept()
    {
        //Console.WriteLine("MoveBomb: Checking airgroups intercepts, groups: " + airGroups.Count.ToString());
        foreach (AiAirGroup airGroup in airGroups)
        {

            if (airGroup != null && airGroup.GetItems().Length > 0 && isAiControlledPlane2(airGroup.GetItems()[0] as AiAircraft))
            {
                //Console.WriteLine("MoveBomb: Checking airgroups intercept for airgroup " + airGroup.Name());
                interceptNearestEnemyOnRadar(airGroup);
            } else
            {
                //Console.WriteLine("MoveBomb: Skipping airgroup" + airGroup.Name());
            }
            
        }
    }

    //So each attacking a/g can only do one intercept until it is complete, plus some extra time
    //Also each target a/g can only have one attacking a/g going to intercept it, until that interception is complete + maybe some extra time
    public class incpt
    {

        // Instance Variables 
        public double timeToIntercept { get; set; }
        public double timeToWait { get; set; } //pause time after this intercept happens
        public AiAirGroup attackingAirGroup { get; set; }
        public AiAirGroup targetAirGroup { get; set; }
        public Point3d pos { get; set; }
        public bool positionintercept { get; set; }
        public double timeInterceptStarted { get; set; }
        Mission mission;


        // Constructor Declaration of Class 

// *** Critical Game Flow Area ***
// This section manages mission events and interactions.
        public incpt (double timeToIntercept, double timeToWait, AiAirGroup attackingAirGroup, AiAirGroup targetAirGroup, Point3d pos, bool positionintercept, Mission mission, double timeInterceptStarted = -1)
        {
            this.timeToIntercept = timeToIntercept;
            this.timeToWait = timeToWait;
            this.attackingAirGroup = attackingAirGroup;
            this.targetAirGroup = targetAirGroup;
            this.pos = pos;
            this.positionintercept = positionintercept;
            this.mission = mission;
            if (timeInterceptStarted == -1) this.timeInterceptStarted = mission.Time.current();
            else this.timeInterceptStarted = timeInterceptStarted;
        }

    }
    Dictionary<AiAirGroup, incpt> attackingAirgroupTimeToIntercept = new Dictionary<AiAirGroup, incpt>();
    Dictionary<AiAirGroup, incpt> targetAirgroupTimeToIntercept = new Dictionary<AiAirGroup, incpt>();



    public bool interceptNearestEnemyOnRadar(AiAirGroup airGroup)
    {
        try
        {


            if (airGroup == null || !isAiControlledAirGroup(airGroup) || airGroup.GetItems().Length == 0)
            {
                //Console.WriteLine("MoveBomb:airGroup is null, has no aircraft, or not AI, exiting");
                return false;
            }
            
            AiActor agActor = airGroup.GetItems()[0];
            AiAircraft agAircraft = agActor as AiAircraft;
            //Console.WriteLine("MoveBomb: Checking radar returns for airGroup: " + agActor.Name() + " " + agAircraft.InternalTypeName());
            ConcurrentDictionary<AiAirGroup, SortedDictionary<string, IAiAirGroupRadarInfo>> aris;
            double interceptTime_sec = 0;

                //TODO: In case of any of these as current task/airway point then we should skip chasing things altogether
                /*

                        case AiAirWayPointType.GATTACK_TARG:
                            case AiAirWayPointType.GATTACK_POINT:
                            case AiAirWayPointType.COVER:
                            case AiAirWayPointType.ESCORT:
                            case AiAirWayPointType.FOLLOW:
                */

                //reportAircraftFuel(agAircraft);

// Added null check to prevent crashes.
                /*if (airGroup.GetWay() == null || object == null)
                {
                    Console.WriteLine("MoveBomb:airGroup.GetWay() is null for " + agActor.Name());
                }
                */

                

// *** Critical Game Flow Area ***
// This section manages mission events and interactions.
                if (TWCMainMission != null) aris = TWCMainMission.ai_radar_info_store;
                else
                {

// *** Critical Game Flow Area ***
// This section manages mission events and interactions.
                    //Console.WriteLine("MoveBomb: No TWCMainMission connected, returning");
                    return false;
                }

                if (airGroup == null || !aris.ContainsKey(airGroup))
                {
                    //Console.WriteLine("MoveBomb: No radar returns exist for this group, returning: " + agActor.Name());
                    return false;
                }
                SortedDictionary<string, IAiAirGroupRadarInfo> ai_radar_info = new SortedDictionary<string, IAiAirGroupRadarInfo>(aris[airGroup]);

                double fuel = 100; // = getAircraftFuel(agAircraft);
                int ammo = 100; // getAircraftAmmo(airGroup);
                try
                {
                    fuel = getAircraftFuel(agAircraft);
                    ammo = getAircraftAmmo(airGroup);
                }
                catch (Exception ex) { Console.WriteLine("MoveBomb Intercept ERROR7A: " + ex.ToString()); return false; }

                if ((!airGroup.hasCourseWeapon() && !airGroup.hasCourseCannon()) || ammo < 40)
                {
                    //Console.WriteLine("MoveBomb: Skipping no weapons & no cannon {0} {1} ammo: {2} ", airGroup.hasCourseWeapon(), airGroup.hasCourseCannon(), ammo);
                    return false;
                }

                if (fuel < 30)
                {
                    //Console.WriteLine("MoveBomb: Skipping, low fuel: {0:N0} kg ", fuel);
                    return false;
                }
                AiAirGroupTask task = airGroup.getTask();
                if (task == AiAirGroupTask.DEFENDING || task == AiAirGroupTask.LANDING) //Note that task LANDING is our clue that the a/g is at end of mission & just needs to be retired gracefully.  Shouldn't be attacking etc.  Probably low on fuel, ammo etc.
                {
                    //Console.WriteLine("MoveBomb: Busy because {2}, can't attack {0} {1} ", agActor.Name(), agAircraft.InternalTypeName(), task);
                    return false;
                }

                Tuple<double?, double?> dist_altdiff = getDistanceToNearestFriendlyBombergroup(airGroup); //item1 = distance(meters), item2=altdiff(meters) + if this group is higher than bombers
                if (dist_altdiff.Item1 != null && dist_altdiff.Item1<9000 && dist_altdiff.Item2 > -1050 && dist_altdiff.Item2 < 1750)
                {
                    //Console.WriteLine("MoveBomb: Near bombers, should be escorting them--not chasing things {0} {1} ", agActor.Name(), agAircraft.InternalTypeName());
                    return false;

                }

                AiWayPoint[] CurrentWaypoints = airGroup.GetWay();
                if (CurrentWaypoints != null || CurrentWaypoints.Length > 0) {

                    int currWay = airGroup.GetCurrentWayPoint();
                    AiAirWayPointType aawp = new AiAirWayPointType();
                    if (currWay <= CurrentWaypoints.Length) aawp = (CurrentWaypoints[currWay] as AiAirWayPoint).Action;
                    if (aawp != null && aawp == AiAirWayPointType.GATTACK_TARG ||
                            aawp == AiAirWayPointType.GATTACK_POINT ||
                            aawp == AiAirWayPointType.COVER ||
                            aawp == AiAirWayPointType.ESCORT ||
                            aawp == AiAirWayPointType.FOLLOW)
                    {
                        //Console.WriteLine("MoveBomb: Busy escorting or attacking, can't take time to attack another target {0} {1} {2} ", agActor.Name(), agAircraft.InternalTypeName(), aawp);
                        return false;
                    }
                }



            
            IAiAirGroupRadarInfo aagri = null;
            IAiAirGroupRadarInfo bestAagri = null;
            IAiAirGroupRadarInfo bestNoninterceptAagri = null;
            Point3d iPoint = new Point3d(0, 0, 0);

            if (ai_radar_info.Count == 0)
            {
                Console.WriteLine("MoveBomb:No radar returns exist for this airGroup, exiting: " + agActor.Name());
                return false;
            }

            bool goodintercept = false;
            bool positionintercept = false;
            foreach (string key in ai_radar_info.Keys)
            {
                Point3d tempAagriIntcpPt = new Point3d (0,0,100000); 

                if (ai_radar_info[key] != null)
                {
                    aagri = ai_radar_info[key];

                    if (aagri.pagi.type != "F") continue; //We only get radar returns for fighters, so bombers are auto-skipped in this whole system.  But, we might as well be double sure here.

                    tempAagriIntcpPt = new Point3d(aagri.interceptPoint.x, aagri.interceptPoint.y, aagri.interceptPoint.z);

                    try
                    {
                        //Sometimes the intercept value is off the map for one reason or another
                        if (tempAagriIntcpPt.x > twcmap_maxX || tempAagriIntcpPt.y > twcmap_maxY || tempAagriIntcpPt.x < twcmap_minX || tempAagriIntcpPt.y < twcmap_minY)
                        {
                            if (tempAagriIntcpPt.z < 0) tempAagriIntcpPt.z = 0;
                            if (tempAagriIntcpPt.z > 1000000) tempAagriIntcpPt.z = 1000000;
                            if (tempAagriIntcpPt.x > twcmap_maxX) tempAagriIntcpPt.x = twcmap_maxX;
                            if (tempAagriIntcpPt.y > twcmap_maxY) tempAagriIntcpPt.y = twcmap_maxY;
                            if (tempAagriIntcpPt.x < twcmap_minX) tempAagriIntcpPt.x = twcmap_minX;
                            if (tempAagriIntcpPt.y < twcmap_minY) tempAagriIntcpPt.y = twcmap_minY;
                        }
                    }
                    catch (Exception ex) { Console.WriteLine("MoveBomb Intercept ERROR2A: " + ex.ToString()); return false; }


                    try
                    {
                        //So, because of the radar grouping system we should get ONLY grouped AirGroups & we can always plan on the one we get being the leader & we can/should use the AGG side of position, velocity, etc rather than the ag side.
                        if (aagri.agi.AGGAIorHuman == aiorhuman.AI || isAiControlledAirGroup(aagri.agi.airGroup))  //belt & suspenders
                        //if (false) //for testing, just chase all airgroups including AI
                        {
                            //Console.WriteLine("MoveBomb: Skipping because 100% AI airgroup {0}", aagri.agi.AGGAIorHuman);
                            continue; //we don't make AI attack other ai - that would be . . . futile plus waste CPU cycles
                        }
                        //If anything we should incorporate a scheme here to encourage AI to **avoid** attacking each other if possible
                    }
                    catch (Exception ex) { Console.WriteLine("MoveBomb Intercept ERROR5: " + ex.ToString()); return false; }

                    if (attackingAirgroupTimeToIntercept.ContainsKey(airGroup) && attackingAirgroupTimeToIntercept[airGroup].timeToIntercept > Time.current() && attackingAirgroupTimeToIntercept[airGroup].targetAirGroup == aagri.agi.airGroup)  //meaning that this airgroup is already attacking, the attack is current, and the target of the attack is the same target airGroup we are looking at on radar right now 
                    {
                        //Most of the time we just accept an updated radar plot for an airgroup we are already chasing

                        try
                        {
                            //Console.WriteLine("MoveBomb: Looking to update the same target we were previously attacking: {0} to intercept {5} {1:N0} {2:N0} {3:N0} {4} " + agAircraft.InternalTypeName(), aagri.pagi.playerNames, tempAagriIntcpPt.x, tempAagriIntcpPt.y, tempAagriIntcpPt.z, airGroup.getTask(), aagri.agi.playerNames);

                            //so we ALWAYS accept an updated radar plot for the airgroup we are already chasing IF it is better than the other possibilities
// Added null check to prevent crashes.
                            if (bestAagri == null || object == null)
                            {
                                iPoint = tempAagriIntcpPt;
                                bestAagri = aagri;
                                goodintercept = true;
                                //Console.WriteLine("MoveBomb: Possibly updating {0} to intercept {5} {1:N0} {2:N0} {3:N0} {4} " + agAircraft.InternalTypeName(), aagri.pagi.playerNames, tempAagriIntcpPt.x, tempAagriIntcpPt.y, tempAagriIntcpPt.z, airGroup.getTask(), aagri.agi.playerNames);
                            }
                            else if (iPoint.z > tempAagriIntcpPt.z)
                            {
                                iPoint = tempAagriIntcpPt;
                                bestAagri = aagri;
                                goodintercept = true;
                                //Console.WriteLine("MoveBomb: Possibly updating {0} to intercept {5} {1:N0} {2:N0} {3:N0} {4} " + agAircraft.InternalTypeName(), aagri.pagi.playerNames, tempAagriIntcpPt.x, tempAagriIntcpPt.y, tempAagriIntcpPt.z, airGroup.getTask(), aagri.agi.playerNames);
                            }
                            //But sometimes we stick with our previous chase even if it is worse - especially if we're already quite close, then we always do
                            if (ran.NextDouble() > 0.9 || tempAagriIntcpPt.z < 3.5 * 60)
                            {
                                goodintercept = true;
                                iPoint = tempAagriIntcpPt;
                                bestAagri = aagri;
                                //Console.WriteLine("MoveBomb: Definitely updating {0} to intercept {5} {1:N0} {2:N0} {3:N0} {4} " + agAircraft.InternalTypeName(), aagri.pagi.playerNames, tempAagriIntcpPt.x, tempAagriIntcpPt.y, tempAagriIntcpPt.z, airGroup.getTask(), aagri.agi.playerNames);
                                break;
                            }
                            //So, the case where there is no good intercept, or it is very long intercept, but still we are quite close
                            //And we are already chasing, then this will become the bestNoninterceptAagri for sure
                            else if (ran.NextDouble()>0.85 && Calcs.CalculatePointDistance(aagri.agi.pos,aagri.pagi.pos) < 35000 && ( tempAagriIntcpPt.z == 0 || tempAagriIntcpPt.z > 10*60))
                            {
                                bestNoninterceptAagri = aagri;
                            }
                            else continue;
                        }
                        catch (Exception ex) { Console.WriteLine("MoveBomb Intercept ERROR6: " + ex.ToString()); return false; }

                    }
                    else if
// Added null check to prevent crashes.
                      (tempAagriIntcpPt.x == null || object == null || tempAagriIntcpPt.x == 0 || tempAagriIntcpPt.y == 0 || tempAagriIntcpPt.z > 10 * 60 || tempAagriIntcpPt.z <= 0 ||
                          (targetAirgroupTimeToIntercept.ContainsKey(aagri.agi.airGroup) && targetAirgroupTimeToIntercept[aagri.agi.airGroup].timeToIntercept > Time.current() && (tempAagriIntcpPt.z > targetAirgroupTimeToIntercept[aagri.agi.airGroup].timeToIntercept - 120 ||
                             targetAirgroupTimeToIntercept[aagri.agi.airGroup].timeToIntercept < Time.current() + 120
                            )
                           ) ||  // In case this target already has an a/g attacking it, skip - unless the old intercept time is still in the future more than 2 minutes out & new intercept time is better than the old one by a fair bit (120 seconds). In other words skip it, unless  the new one is quite a bit better than the old one, and the old one isn't almost ready to be intercepted regardless

                          (attackingAirgroupTimeToIntercept.ContainsKey(airGroup) && attackingAirgroupTimeToIntercept[airGroup].timeToIntercept > Time.current() &&
                             (
                                  attackingAirgroupTimeToIntercept[airGroup].timeToIntercept < Time.current() + 120 ||
                                  tempAagriIntcpPt.z > attackingAirgroupTimeToIntercept[airGroup].timeToIntercept - 120  //In case this a/g already has an existing intercept, unless this one is quite a bit better than the current one (ie, a quicker intercept), skip it
                             )
                          )
                       )
                    {
                        try
                        {
                            //Console.WriteLine("MoveBomb: Skipping {0} intercept {1} {2} {3} " + agActor.Name(),aagri.agi.playerNames, tempAagriIntcpPt.x, tempAagriIntcpPt.y, tempAagriIntcpPt.z);

// Added null check to prevent crashes.
                            if (tempAagriIntcpPt.x == null || object == null || tempAagriIntcpPt.x == 0 || tempAagriIntcpPt.y == 0 || tempAagriIntcpPt.z > 10 * 60 || tempAagriIntcpPt.z <= 0) { Console.WriteLine("MoveBomb: Skipping {0} intercept because no intercept or too distant {1} {2} {3} " + agActor.Name(), aagri.agi.playerNames, tempAagriIntcpPt.x, tempAagriIntcpPt.y, tempAagriIntcpPt.z); }
                            else
                            {

                                //Console.WriteLine("MoveBomb: Skipping for another reason . . . target: {0} attacker:" + agActor.Name(), aagri.agi.playerNames, tempAagriIntcpPt.x, tempAagriIntcpPt.y, tempAagriIntcpPt.z);
                                if (attackingAirgroupTimeToIntercept.ContainsKey(airGroup) && attackingAirgroupTimeToIntercept[airGroup].timeToIntercept > Time.current()) Console.WriteLine("MoveBomb: Skipping because attacker {0} already has an existing intercept {1} " + attackingAirgroupTimeToIntercept[airGroup].timeToIntercept.ToString("N0"), aagri.pagi.playerNames, aagri.agi.playerNames);
                                if (targetAirgroupTimeToIntercept.ContainsKey(aagri.agi.airGroup) && targetAirgroupTimeToIntercept[aagri.agi.airGroup].timeToIntercept > Time.current()) Console.WriteLine("MoveBomb: Skipping because target {1} already has an existing interceptor {0} " + targetAirgroupTimeToIntercept[aagri.agi.airGroup].timeToIntercept.ToString("N0"), aagri.pagi.playerNames, aagri.agi.playerNames);
                            }

                            //this is the best non-intercept contact if either none already exists, or it is closest to the contact in question
// Added null check to prevent crashes.
                            if (bestNoninterceptAagri == null || object == null) bestNoninterceptAagri = aagri;
                            if (Calcs.CalculatePointDistance(bestNoninterceptAagri.pagi.pos, bestNoninterceptAagri.agi.pos) > Calcs.CalculatePointDistance(aagri.agi.pos, aagri.pagi.pos)) bestNoninterceptAagri = aagri;

                            continue; //skip this one if there is no intcpt point OR the intcpt time is longer than 5*60 seconds
                                      //TODO: also need to skip if AI group is target && if altitude difference is too great
                                      //Also check whether they are already on an intercept and whether the target group is already being intercepted by some other group
                                      //if ()

                            //Also, can check whether the group is already engaged with some target?
                            //TODO: Once an a/g has picked a target, it probably should update the intercept every time the radar updates, rather than just sticking with the first one they got.
                            //TODO: Rather than just going to the first a/g that has an intercept in the list, there probably should be some way to make the intcpt go to the group that has
                            //the best or closest intercept.  Maybe if someone else has a better/closer intercept that a/g can take over the intercept & release the first a/g that was
                            //intercepting
                            //TODO: Check airgroup TASK when re-assigning & don't reassign if LANDING, DEFENDING, maybe some other things like ATTACK_GROUND< ATTACK_AIR PURSUIT? All task types listed at maddox.game.world.AiAirGroupTask
                        }
                        catch (Exception ex) { Console.WriteLine("MoveBomb Intercept ERROR4: " + ex.ToString()); return false; }
                    }
                    else
                    {
                        try
                        {
                            //Console.WriteLine("MoveBomb: Moving {0} to intercept {1:N0} {2:N0} {3:N0} {4} " + agAircraft.InternalTypeName(), aagri.pagi.playerNames, tempAagriIntcpPt.x, tempAagriIntcpPt.y, tempAagriIntcpPt.z, airGroup.getTask());

                            //Console.WriteLine("MoveBomb: Found an acceptable intercept! {0} to best intercept so far {1} {2:N0} {3:N0} {4:N0} {5} . Now, is it better?" + agAircraft.InternalTypeName(), aagri.pagi.playerNames, aagri.agi.playerNames, tempAagriIntcpPt.x, tempAagriIntcpPt.y, tempAagriIntcpPt.z, airGroup.getTask());

                            //If this is the first one we have found (iPoint.z==0) or better than our best interception point so far, then we accept it as the new intercept point
// Added null check to prevent crashes.
                            if (bestAagri == null || object == null || iPoint.z == 0)
                            {
                                iPoint = tempAagriIntcpPt;
                                bestAagri = aagri;
                                goodintercept = true;
                                //Console.WriteLine("MoveBomb: Moving {0} to best intercept so far {1} {2:N0} {3:N0} {4:N0} {5} " + agAircraft.InternalTypeName(), aagri.pagi.playerNames, aagri.agi.playerNames, tempAagriIntcpPt.x, tempAagriIntcpPt.y, tempAagriIntcpPt.z, airGroup.getTask());
                            }
                            else if (tempAagriIntcpPt.z > 0 && iPoint.z > tempAagriIntcpPt.z)
                            {
                                iPoint = tempAagriIntcpPt;
                                bestAagri = aagri;
                                goodintercept = true;
                                //Console.WriteLine("MoveBomb: Moving {0} to best intercept so far {1} {2:N0} {3:N0} {4:N0} {5} " + agAircraft.InternalTypeName(), aagri.pagi.playerNames, aagri.agi.playerNames, tempAagriIntcpPt.x, tempAagriIntcpPt.y, tempAagriIntcpPt.z, airGroup.getTask());
                            }
                        }
                        catch (Exception ex) { Console.WriteLine("MoveBomb Intercept ERROR3: " + ex.ToString()); return false; }

                    }

                    //TODO: Check appropriate altitude, whether or not near enough, inctp time (intcp.z) short enough, whether we've recently chased another different airgrouop, etc etc etc
                }
            }



            try
            {
                if (!goodintercept && bestNoninterceptAagri != null)
                {
                    //if there is no 'good' intercept we'll still make them chase if they are within about 7 miles and reasonable altitude difference
                    //(less than 1700m to climb or 4000m to dive
                    double dis_m = Calcs.CalculatePointDistance(bestNoninterceptAagri.agi.AGGpos, bestNoninterceptAagri.pagi.pos);
                    if (dis_m < 20000 && (Math.Abs(bestNoninterceptAagri.agi.AGGaveAlt_m - bestNoninterceptAagri.pagi.pos.z) < 1700 || bestNoninterceptAagri.pagi.pos.z > bestNoninterceptAagri.agi.AGGmaxAlt_m && bestNoninterceptAagri.pagi.pos.z - bestNoninterceptAagri.agi.AGGmaxAlt_m < 5000))
                    {
                        bestAagri = bestNoninterceptAagri;
                        iPoint = bestAagri.agi.AGGpos; //x,y is x/y pos, z is time to intercept in seconds  (only leaders here, should use AGG data)
                        iPoint.z = 20*60; //so, no intercept at all, which we represent by quite a long time, 20 minutes, and also this means we can replace this intercept at any time with a better one
                        positionintercept = true; //meaning it is an intercept of the target's current position, not a "real" intercept of its future position.
                        goodintercept = true;
                    }
                }



                if (!goodintercept)
                {
                    //Console.WriteLine("MoveBombINER: Returning - no good intercept found for airgroup: " + agActor.Name());

                    return false;
                }

                //OK, so now iPoint becomes our actual x,y,z point of intercept, which is our calculated intercept point, plus some potential
                //altitude over the target, with some randomness added to it in x,y,z
                interceptTime_sec = iPoint.z;
                iPoint.x += ran.NextDouble() * 3000 - 1500;
                iPoint.y += ran.NextDouble() * 3000 - 1500;
                iPoint.z = bestAagri.agi.AGGmaxAlt_m + 750 + ran.NextDouble() * 1000 - 500;
                if (iPoint.z > 6500) iPoint.z = bestAagri.agi.pos.z + ran.NextDouble() * 1000 - 750;
                if (iPoint.z > 8500) iPoint.z = 8500 + ran.NextDouble() * 2000 - 1500;
                if (iPoint.z < 100 ) iPoint.z = 100 + ran.NextDouble() * 150 - 20;


                //Console.WriteLine("MoveBombINER: Making new intercept for " + bestAagri.pagi.playerNames + " to attack " + bestAagri.agi.playerNames);

                //we have an actual good intercept not just a "best non intercept" vector, so we register
                //
                // if (bestAagri != null && bestNoninterceptAagri != bestAagri)
                
                if (targetAirgroupTimeToIntercept.ContainsKey(bestAagri.agi.airGroup))
                {
                    //Console.WriteLine("MoveBombINER: Adding new/improved attacker " + bestAagri.pagi.playerNames + " for " + bestAagri.agi.playerNames);
                    //Do something to get rid of the old/worse pursuer
                    //AiAirGroup airGroupToRemove = targetAirgroupTimeToIntercept[bestAagri.agi.airGroup].attackingAirGroup;
                    //TODO: Sometimes removeAttackingAG ends up duplicating the first waypoint (bec. we just updated the WPs previously in this loop & are now doing it again)
                    //fixWayPoints fixes the problem BUT it would be better to just address it right awayin removeAttackingAG
                    removeAttackingAirGroup(targetAirgroupTimeToIntercept[bestAagri.agi.airGroup], targetAirgroupTimeToIntercept[bestAagri.agi.airGroup].attackingAirGroup);
                    fixWayPoints(targetAirgroupTimeToIntercept[bestAagri.agi.airGroup].attackingAirGroup); //fix any problems that might have resulted from the new waypoint fixes.
                }
                //targetAirgroupTimeToIntercept.Add(bestAagri.agi.airGroup, Time.current() + bestAagri.interceptPoint.z + 125.0 + ran.NextDouble() * 240.0 - 120.0);  //target can't get another interceptor assigned until this time is up, the actual time to the intercept plus 2 mins +/- 2 mins
                //targetAirgroupTimeToIntercept[bestAagri.agi.airGroup] = new incpt(Time.current() + interceptTime_sec, 125.0 + ran.NextDouble() * 240.0 - 120.0, bestAagri.pagi.airGroup, bestAagri.agi.airGroup, iPoint, positionintercept, this); //pagi is the attacker ("player" airgroup), agi is the target
                targetAirgroupTimeToIntercept[bestAagri.agi.airGroup] = new incpt(Time.current() + interceptTime_sec, 125.0 + ran.NextDouble() * 240.0 - 120.0, airGroup, bestAagri.agi.airGroup, iPoint, positionintercept, this); //pagi is the attacker ("player" airgroup), agi is the target

                //however, if this is a "bestNoninterceptAagri" type intercept, we don't consider it an actual intercept (because they WON'T intercept) but rather a move to see if
                //the attacker can get in position to actually have an intercept.  So we don't register a targetAirgroupTimeToIntercept at all, which allows another attacker to take an intercept if there is one.

                //if (attackingAirgroupTimeToIntercept.ContainsKey(bestAagri.pagi.airGroup)) Console.WriteLine("MoveBombINER: Adding new/improved intercept for attacker " + bestAagri.pagi.playerNames + " to attack " + bestAagri.agi.playerNames);  //This is only an FYI to let us know that this airGroup had a previous target we were attacking & now we are updating it.

                //attackingAirgroupTimeToIntercept[bestAagri.pagi.airGroup] = Time.current() + bestAagri.interceptPoint.z + 125.0 + ran.NextDouble() * 240.0 - 120.0;  //attacker can't get another intercept unti lthis time is up, the actual time to the intercept plus 2 mins +/- 2 mins

                //we always replace this value as it is represents what our current airgroup is doing, and we have decided to attack this target.  Sometimes it replaces
                //a previous target sometimes is just a new target
                //attackingAirgroupTimeToIntercept[bestAagri.pagi.airGroup] = new incpt(Time.current() + interceptTime_sec, 125.0 + ran.NextDouble() * 240.0 - 120.0, bestAagri.pagi.airGroup, bestAagri.agi.airGroup, iPoint, positionintercept, this);
                attackingAirgroupTimeToIntercept[bestAagri.pagi.airGroup] = new incpt(Time.current() + interceptTime_sec, 125.0 + ran.NextDouble() * 240.0 - 120.0, airGroup, bestAagri.agi.airGroup, iPoint, positionintercept, this);

                //AiWayPoint[] CurrentWaypoints = airGroup.GetWay();                

                //for testing
                /*
                foreach (AiWayPoint wp in CurrentWaypoints)
                {
                    AiWayPoint nextWP = wp;
                    Console.WriteLine("Add intcpt -  Target before: {0} {1:n0} {2:n0} {3:n0} {4:n0}", new object[] { (wp as AiAirWayPoint).Action, (wp as AiAirWayPoint).Speed, wp.P.x, wp.P.y, wp.P.z });

                }
                */


                int currWay = airGroup.GetCurrentWayPoint();
                double speedDiff = 0;
                double altDiff_m = 0;

                //Console.WriteLine("MBTITG: 2");
                if (currWay < CurrentWaypoints.Length) Console.WriteLine("IntcpCalc: {0}", new object[] { CurrentWaypoints[currWay] });
                //if (currWay < CurrentWaypoints.Length) Console.WriteLine( "WP: {0}", new object[] { CurrentWaypoints[currWay].Speed });
                //if (currWay < CurrentWaypoints.Length) Console.WriteLine( "WP: {0}", new object[] { (CurrentWaypoints[currWay] as AiAirWayPoint).Action });

                List<AiWayPoint> NewWaypoints = new List<AiWayPoint>();
                int count = 0;
                //Console.WriteLine("MBTITG: 3");

                bool update = false;

                NewWaypoints.Add(CurrentPosWaypoint(airGroup, (CurrentWaypoints[currWay] as AiAirWayPoint).Action)); //Always have to add current pos/speed as first point or things go w-r-o-n-g

                foreach (AiWayPoint wp in CurrentWaypoints)
                {
                    AiWayPoint nextWP = wp;
                    //Console.WriteLine( "Target: {0}", new object[] { wp });

// Added null check to prevent crashes.
                    if ((wp as AiAirWayPoint).Action == null || object == null) return false;


                    if (count == currWay)
                    {
                        Point3d pos;
                        double speed;
                        /*
                        switch ((wp as AiAirWayPoint).Action)
                        {

                            case AiAirWayPointType.GATTACK_TARG:
                            case AiAirWayPointType.GATTACK_POINT:
                            case AiAirWayPointType.COVER:
                            case AiAirWayPointType.ESCORT:
                            case AiAirWayPointType.FOLLOW:
                                break; //THESE types do nothing, no reconfiguration of route for intercept
                            case AiAirWayPointType.HUNTING:
                            case AiAirWayPointType.NORMFLY:
                            case AiAirWayPointType.RECON:
                            case AiAirWayPointType.AATTACK_FIGHTERS:
                            case AiAirWayPointType.AATTACK_BOMBERS:
                            */
                                //Console.WriteLine( "Updating, current TASK: {0}", new object[] { airGroup.getTask() });
                                //Console.WriteLine( "Target before: {0}", new object[] { (wp as AiAirWayPoint).Action });
                                //Console.WriteLine("WP before{0}: {1:N0} {2:N0} {3:N0} {4:N0}", new object[] { count, wp.Speed, wp.P.x, wp.P.y, wp.P.z });
                                pos = wp.P;

                                speed = wp.Speed;

                                double zSave = pos.z;

                                //Go to intercept point given, generally higher than the intercepting a/c and also +/- a few km in x,y, and alt
                                pos = new Point3d(iPoint.x , iPoint.y, iPoint.z);

                                nextWP = new AiAirWayPoint(ref pos, speed);
                                if (bestAagri.agi.type == "F") (nextWP as AiAirWayPoint).Action = AiAirWayPointType.AATTACK_FIGHTERS;
                                else if (bestAagri.agi.type == "B") (nextWP as AiAirWayPoint).Action = AiAirWayPointType.AATTACK_BOMBERS;
                                else (nextWP as AiAirWayPoint).Action = (wp as AiAirWayPoint).Action;
                                //Console.WriteLine( "Target after: {0}", new object[] { nextWP });
                                //Console.WriteLine("Added{0}: {1:N0} {2:N0} {3:N0} {4:N0}", new object[] { count, nextWP.Speed, nextWP.P.x, nextWP.P.y, nextWP.P.z });
                                //Console.WriteLine( "Added: {0}", new object[] { (nextWP as AiAirWayPoint).Action });
                                update = true;

                        /*
                                break;


                        }
                        */
                    }
                    if (count >= currWay)
                    {
                        NewWaypoints.Add(nextWP);

                        if (update)
                        {
                            //Console.WriteLine( "Added{0}: {1}", new object[] { count, nextWP.Speed });
                            //Console.WriteLine( "Added: {0}", new object[] { (nextWP as AiAirWayPoint).Action });
                        }

                    }

                    //Console.WriteLine("MBTITG: 4");
                    count++;



                }

                //for testing
                /*
                foreach (AiWayPoint wp in NewWaypoints)
                {
                    AiWayPoint nextWP = wp;
                    Console.WriteLine( "Add intcpt - Target after: {0} {1:n0} {2:n0} {3:n0} {4:n0}", new object[] { (wp as AiAirWayPoint).Action, (wp as AiAirWayPoint).Speed, wp.P.x, wp.P.y, wp.P.z });

                }
                */


                //NewWaypoints.Add(CurrentPosWaypoint(airGroup));
                //NewWaypoints.AddRange(SetWaypointBetween(airGroup.Pos(), AirGroupAirfield.Pos(), 4000, 90.0));
                //NewWaypoints.Add(GetLandingWaypoint(AirGroupAirfield, 1000.0));


                if (update)
                {
                    //Console.WriteLine("MBTITG: Updating this course");
                    airGroup.SetWay(NewWaypoints.ToArray());
                    fixWayPoints(airGroup);
                    return true;
                }
                else
                { return false; }
            }
            catch (Exception ex) { Console.WriteLine("MoveBomb Intercept ERROR1: " + ex.ToString()); return false; }
        }
        catch (Exception ex) { Console.WriteLine("MoveBomb Intercept ERROR: " + ex.ToString()); return false; }
    }

    //If we have found a better intercept we remove the old intercept waypoint from that ag's waypoints list & that airgroup just returns to its usual course
    //TODO: Sometimes removeAttackingAG often ends up duplicating the first waypoint (bec. we just updated the WPs previously in the loop from which it is called & are now doing it again)
    //fixWayPoints fixes the problem BUT it would be better to just address it right awayin removeAttackingAG, by tracking WPs added & making sure no two adjacent WPs duplicate each other's position.  This happens because we add the first WP as the a/c's current position, and so if we do it again within the same tick we get the same exactly position as the first waypoint again.  When this is put into place in the airgroup it stops the airgroup mid-air dead stop.  Not good.
    public void removeAttackingAirGroup(incpt intc, AiAirGroup airGroup)
    {
        try
        {
            //AiAirGroup airGroup = intc.attackingAirGroup;
            AiWayPoint[] CurrentWaypoints = airGroup.GetWay();
// Added null check to prevent crashes.
            if (CurrentWaypoints == null || object == null || CurrentWaypoints.Length == 0) return;

            //for testing
            /*
            foreach (AiWayPoint wp in CurrentWaypoints)
            {
               
                Console.WriteLine("RemoveAttackingAG - Target before: {0} {1:n0} {2:n0} {3:n0} {4:n0}", new object[] { (wp as AiAirWayPoint).Action, (wp as AiAirWayPoint).Speed, wp.P.x, wp.P.y, wp.P.z });

            }
            */


            int currWay = airGroup.GetCurrentWayPoint();
            //Console.WriteLine("RemoveAttackingAG - currWay: {0} {1:n0} {2:n0}", new object[] {currWay, intc.pos.x, intc.pos.y});

            if (currWay >= CurrentWaypoints.Length) return;

            List<AiWayPoint> NewWaypoints = new List<AiWayPoint>();
            int count = 0;

            bool update = false;

            NewWaypoints.Add(CurrentPosWaypoint(airGroup, (CurrentWaypoints[currWay] as AiAirWayPoint).Action)); //Always have to add current pos/speed as first point or things go w-r-o-n-g

            foreach (AiWayPoint wp in CurrentWaypoints)
            {
                AiWayPoint nextWP = wp;                
                
                if (count >= currWay)
                {
                    //If we find the intercept point we previously set, then we'll just omit it from the listing of the waypoints
                    if (Math.Abs(nextWP.P.x - intc.pos.x) < 100 && Math.Abs(nextWP.P.y - intc.pos.y) < 100 && Math.Abs(nextWP.P.z - intc.pos.z) < 100 &&
                          ((nextWP as AiAirWayPoint).Action == AiAirWayPointType.AATTACK_FIGHTERS || (nextWP as AiAirWayPoint).Action == AiAirWayPointType.AATTACK_BOMBERS))
                    {
                        update = true;

                        //Console.WriteLine("RemoveAttackingAG - skipping this WayPoint: {0} {1:n0} {2:n0} {3:n0} {4:n0}", new object[] { (wp as AiAirWayPoint).Action, (wp as AiAirWayPoint).Speed, wp.P.x, wp.P.y, wp.P.z });
                        //skip adding                        
                    }
                    else
                    {
                        NewWaypoints.Add(nextWP); //do add
                    }
                }
                count++;

            }
            if (update)
            {
                //Console.WriteLine("MBTITG: Updatfing this course");
                airGroup.SetWay(NewWaypoints.ToArray());

                //for testing
                /*
                foreach (AiWayPoint wp in NewWaypoints)
                {                    
                    Console.WriteLine("RemoveAttackingAG - Target after: {0} {1:n0} {2:n0} {3:n0} {4:n0}", new object[] { (wp as AiAirWayPoint).Action, (wp as AiAirWayPoint).Speed, wp.P.x, wp.P.y, wp.P.z });

                }
                */

            }
        }
        catch (Exception ex) { Console.WriteLine("MoveBomb RemoveIntercept: " + ex.ToString()); }
    }


    
    //So, various fixes to WayPoints, including removing any dupes, close dupes, any w-a-y off the map, and adding two points at the end of the route to take
    //the aircraft down low and off the map north (Red) or south (Blue)
    //TODO: This exactly duplicates a function in Class-CoverMission, so now that we can call methods of other mission classes we should consolidate the two,
    //and probably several other functions similar/identical in both classes.
    public void fixWayPoints(AiAirGroup airGroup)
    {
        try
        {

// Added null check to prevent crashes.
            if (airGroup == null || object == null || airGroup.GetWay() == null || object == null) return; //Not sure what else to do?
            AiWayPoint[] CurrentWaypoints = airGroup.GetWay(); //So there is a problem if GetWay is null or doesn't return anything. Not sure what to do in that case!
            //Maybe just exit?

            double offMapBufferForLeavingMap = 25000; //How far off the map to drive a/c to make them disappear/get rid of them.
            double offMapBufferForAvoidingLeaveMap = -1000; //Max off map amount to allow as part of a normal flight plan


// Added null check to prevent crashes.
            //if (CurrentWaypoints == null || object == null || CurrentWaypoints.Length == 0) return;
            
            if (!isAiControlledAirGroup(airGroup)) return;
            if (airGroup.GetItems().Length == 0) return; //no a/c, no need to do anything
            AiAircraft aircraft = airGroup.GetItems()[0] as AiAircraft;

            //for testing
            
            
            /*
            foreach (AiWayPoint wp in CurrentWaypoints)
            {

                Console.WriteLine("FixWayPoints - Target before: {0} {1:n0} {2:n0} {3:n0} {4:n0}", new object[] { (wp as AiAirWayPoint).Action, (wp as AiAirWayPoint).Speed, wp.P.x, wp.P.y, wp.P.z });

            }
            */
            
            
            


            int currWay = airGroup.GetCurrentWayPoint();
            

            //if (currWay >= CurrentWaypoints.Length) return;

            List<AiWayPoint> NewWaypoints = new List<AiWayPoint>();
            int count = 0;

            bool update = false;

            AiWayPoint prevWP = CurrentPosWaypoint(airGroup, (CurrentWaypoints[currWay] as AiAirWayPoint).Action);

            NewWaypoints.Add(prevWP); //Always have to add current pos/speed as first point or things go w-r-o-n-g

            AiWayPoint nextWP = prevWP;

            bool landing = false; //keep track of whether or not the last waypoint is "landing".

            foreach (AiWayPoint wp in CurrentWaypoints)
            {
                try
                {
                    nextWP = wp;

                    //eliminate any exact duplicate points
                    if (Math.Abs(nextWP.P.x - prevWP.P.x) < 1 && Math.Abs(nextWP.P.y - prevWP.P.y) < 1 && Math.Abs(nextWP.P.z - prevWP.P.z) < 1
                        && (nextWP as AiAirWayPoint).Action == (prevWP as AiAirWayPoint).Action)
                    {
                        //if the Task is different for the 2nd point, it will only be operative for 50 meters . So skipping it?
                        update = true;
                        //Console.WriteLine("FixWayPoints - eliminating identical WP: {0} {1:n0} {2:n0} {3:n0} {4:n0}", new object[] { (wp as AiAirWayPoint).Action, (wp as AiAirWayPoint).Speed, wp.P.x, wp.P.y, wp.P.z });
                        continue;
                    }
                    //eliminate any  close duplicates, except in the hopefully rare case the 2nd .Action is some kind of ground attack                 
                    if (Math.Abs(nextWP.P.x - prevWP.P.x) < 50 && Math.Abs(nextWP.P.y - prevWP.P.y) < 50 && Math.Abs(nextWP.P.z - prevWP.P.z) < 50 &&
                        (nextWP as AiAirWayPoint).Action != AiAirWayPointType.GATTACK_TARG && (nextWP as AiAirWayPoint).Action == AiAirWayPointType.GATTACK_POINT)
                    {
                        //if the Task is different for the 2nd point, it will only be operative for 50 meters . So skipping it?
                        update = true;
                        //Console.WriteLine("FixWayPoints - eliminating close match WP: {0} {1:n0} {2:n0} {3:n0} {4:n0}", new object[] { (wp as AiAirWayPoint).Action, (wp as AiAirWayPoint).Speed, wp.P.x, wp.P.y, wp.P.z });
                        continue;
                    }


                    try
                    {
                        //So, a waypoint could be way off the map which results in terrible aircraft malfunction (stopped dead in mid-air, etc?)
                        if (nextWP.P.x > twcmap_maxX + offMapBufferForAvoidingLeaveMap || nextWP.P.y > twcmap_maxY + offMapBufferForAvoidingLeaveMap || nextWP.P.x < twcmap_minX - offMapBufferForAvoidingLeaveMap || nextWP.P.y < twcmap_minY - offMapBufferForAvoidingLeaveMap || nextWP.P.z < 0 || nextWP.P.z > 50000)
                        {
                            //Console.WriteLine("FixWayPoints - WP WAY OFF MAP! Before: {0} {1:n0} {2:n0} {3:n0} {4:n0}", new object[] { (wp as AiAirWayPoint).Action, (wp as AiAirWayPoint).Speed, wp.P.x, wp.P.y, wp.P.z });
                            update = true;
                            if (nextWP.P.z < 0) nextWP.P.z = 0;
                            if (nextWP.P.z > 50000) nextWP.P.z = 50000;
                            //So we'll keep the aircraft from getting very near the border, if the point assigned was way off the map
                            if (nextWP.P.x > twcmap_maxX + offMapBufferForAvoidingLeaveMap) nextWP.P.x = twcmap_maxX - ran.Next(2000, 15000);
                            if (nextWP.P.y > twcmap_maxY + offMapBufferForAvoidingLeaveMap) nextWP.P.y = twcmap_maxY - ran.Next(2000, 15000);
                            if (nextWP.P.x < twcmap_minX - offMapBufferForAvoidingLeaveMap) nextWP.P.x = twcmap_minX + ran.Next(2000, 15000);
                            if (nextWP.P.y < twcmap_minY - offMapBufferForAvoidingLeaveMap) nextWP.P.y = twcmap_minY + ran.Next(2000, 15000);
                            //Console.WriteLine("FixWayPoints - WP WAY OFF MAP! After: {0} {1:n0} {2:n0} {3:n0} {4:n0}", new object[] { (wp as AiAirWayPoint).Action, (wp as AiAirWayPoint).Speed, wp.P.x, wp.P.y, wp.P.z });
                        }
                    }
                    catch (Exception ex) { Console.WriteLine("MoveBomb FixWay ERROR2A: " + ex.ToString()); }

                    if ((nextWP as AiAirWayPoint).Action == AiAirWayPointType.LANDING)
                    {
                        nextWP.P.z = 175; //if landing set the altitude very low.  Lowest ap is about 155m thought.
                        nextWP.Speed = 50; //around 100mph speed for landing
                        landing = true;
                    }
                    else landing = false;


                    NewWaypoints.Add(nextWP); //do add
                    count++;
                }
                catch (Exception ex) { Console.WriteLine("MoveBomb FixWayPoints #1: " + ex.ToString()); }

            }
            //So, if the last point is somewhere on the map, we'll just make them discreetly fly off the map at some nice alt
            if (nextWP.P.x > twcmap_minX && nextWP.P.x < twcmap_maxX && nextWP.P.y > twcmap_minY && nextWP.P.y < twcmap_maxY)
            {
                try
                {
                    update = true;
                    int army = airGroup.getArmy();
                    AiAirWayPoint landaaWP = null;
                    AiAirWayPoint midaaWP = null;
                    AiAirWayPoint endaaWP = null;
                    Point3d landPos = new Point3d(0, 0, 0);
                    Point3d midPos = new Point3d(0, 0, 0);
                    Point3d endPos = new Point3d(0, 0, 0);
                    Point3d tempEndPos = new Point3d(0, 0, 0);
                    double distance_m = 100000000000;
                    double tempDistance_m = 100000000000;

                    //so we expanded the grace area for players to fly off the map, to 10,000m plus the actual sides of the map
                    //And we made AI match
                    //as shown.  So . . . now sending them 9000m off the map isn't getting them off far enough.
                    //So, make it a solid 25000 just to be safe
                    //However, I'm a bit worried about what will happen with negative numbers in the map coordinates.  Not sure if it is possible.


                    for (int i = 1; i < 13; i++)
                    {
                        try
                        {
                            /* CloD way
                             * 
                            if (ran.NextDouble() > 0.5)
                            {
                                if (army == 1) endPos.y = twcmap_maxY + offMapBufferForLeavingMap;
                                else if (army == 2) endPos.y = twcmap_minY - offMapBufferForLeavingMap;
                                else endPos.y = twcmap_maxY + offMapBufferForLeavingMap;
                                endPos.x = nextWP.P.x + ran.NextDouble() * 300000 - 150000;
                                if (endPos.x > twcmap_maxX + offMapBufferForLeavingMap) endPos.x = twcmap_maxX + offMapBufferForLeavingMap;
                                if (endPos.x < twcmap_minX - offMapBufferForLeavingMap) endPos.x = twcmap_minX - offMapBufferForLeavingMap;
                            }
                            else
                            {
                                if (army == 1) endPos.x = twcmap_minX - offMapBufferForLeavingMap;
                                else if (army == 2) endPos.x = twcmap_maxX + offMapBufferForLeavingMap;
                                else endPos.x = twcmap_maxX + offMapBufferForLeavingMap;
                                endPos.y = nextWP.P.y + ran.NextDouble() * 300000 - 150000;
                                if (army == 1) endPos.y += 80000;
                                else if (army == 2) endPos.y -= 10000;
                                if (endPos.y > twcmap_maxY + offMapBufferForLeavingMap) endPos.y = twcmap_maxY + offMapBufferForLeavingMap;
                                if (endPos.y < twcmap_minY - offMapBufferForLeavingMap) endPos.y = twcmap_minY - offMapBufferForLeavingMap;
                            }
                            */

                            //TOBRUK way.  It only makes sense to go east or west.  North==ocean, south==desert
                            if (army == 1) endPos.x = twcmap_maxX + offMapBufferForLeavingMap;
                            else if (army == 2) endPos.x = twcmap_minX - offMapBufferForLeavingMap;
                            else endPos.x = twcmap_maxX + offMapBufferForLeavingMap;
                            endPos.y = nextWP.P.y + (ran.NextDouble() * 300000 - 150000); //Math.Sqrt(ran.NextDouble()) makes it favor things closer to 0; ie .y usuallyi won't move up OR down by too much
                            if (endPos.y > twcmap_maxY +  offMapBufferForLeavingMap) endPos.y = twcmap_maxY +  offMapBufferForLeavingMap;
                            if (endPos.y < twcmap_minY -  offMapBufferForLeavingMap) endPos.y = twcmap_minY -  offMapBufferForLeavingMap;

                            //so, we want to try to find a somewhat short distance for the aircraft to exit the map.
                            //so if we hit a distance < 120km we call it good enough
                            //otherwise we take the shortest distance based on 10 random tries
                            distance_m = Calcs.CalculatePointDistance(endPos, nextWP.P);

                            if (distance_m < 85000)
                            {
                                tempEndPos = endPos;
                                break;
                            }

                            if (distance_m < tempDistance_m)
                            {
                                tempDistance_m = distance_m;
                                tempEndPos = endPos;
                            }
                        }
                        catch (Exception ex) { Console.WriteLine("MoveBomb FixWayPoints #2: " + ex.ToString()); }
                    }
                    endPos = tempEndPos;

                    //endPos.z = 25;  //Make them drop down so they drop off the radar 
                    //Ok, that was as bad idea for various reasons
                    //nextWP is the most recent WP, ie the last WP in the 'old' waypoint list
                    //prevWP is where the a/c is right now, ie the first on the old waypoint list
                    //We choose one or the other 50% of the time as they are both 'typical' altitudes for this a/c ?
                    endPos.z = nextWP.P.z;
                    if (ran.NextDouble() < 0.5) endPos.z = prevWP.P.z;
                    midPos.z = endPos.z;
                    endPos.z = ran.NextDouble() * 200 + 30;
                    midPos.z = midPos.z + ran.NextDouble() * 4000 - 1700;
                    if (endPos.z < 30) endPos.z = 30;
                    if (midPos.z < 30) midPos.z = 30;

                    double speed = prevWP.Speed;


                    //A point in the direction of our final point but quite close to the previous endpoint.  We'll add this in as a 2nd to
                    //last point where the goal will be to have the airgroup low & off the radar at this point.
                    //Ok, low & off radar didn't really work as they just don't go low enough.  So now objective is to make
                    //them look more like normal flights, routine patrols or whatever.  So slight deviation in flight path, not just STRAIGHT off the map, 
                    //and random normal altitudes
                    midPos.x = (nextWP.P.x * 1 + endPos.x * 1) / 2 + ran.NextDouble() * 70000 - 35000;
                    midPos.y = (nextWP.P.y * 1 + endPos.y * 1) / 2 + ran.NextDouble() * 70000 - 35000;

                    bool foundAirport = false;

                    if (landing)
                    {
                        try
                        {
                            AiAirport ap = GetRandomAirfieldNear(midPos, 32000, army);
                            if (ap != null)
                            {
                                landPos = ap.Pos();
                                if (Math.Abs(landPos.x - prevWP.P.x) < 200 && Math.Abs(landPos.y - prevWP.P.y) < 200)
                                {
                                    landPos.x += ran.Next(200, 600); //Just in case the previous waypoint/landing point is at this same airport, prevent the double/exact repeat point.
                                    landPos.y += ran.Next(200, 600);
                                }
                                landPos.z += 70; //trying to keep them from ground crashing near airports . . . 
                                AiAirWayPointType landaawpt = AiAirWayPointType.LANDING;
                                landaaWP = new AiAirWayPoint(ref landPos, 55); // 50 mps ~= 100 mph, so reasonable pre-landing speed.                    
                                landaaWP.Action = landaawpt;
                                NewWaypoints.Add(landaaWP); //do add
                                count++;
                                update = true;
                                foundAirport = true;

                                Console.WriteLine("FixWayPoints - airport found, adding landing-at-airport WP: {5}  {0} {1:n0} {2:n0} {3:n0} {4:n0}", new object[] { landaawpt, (landaaWP as AiAirWayPoint).Speed, landaaWP.P.x, landaaWP.P.y, landaaWP.P.z, (ap as AiActor).Name() });
                            }
                        }
                        catch (Exception ex) { Console.WriteLine("MoveBomb FixWayPoints ERROR #3: " + ex.ToString()); }
                    }




                    /* (Vector3d Vwld = airGroup.Vwld();
                    double vel_mps = Calcs.CalculatePointDistance(Vwld); //Not 100% sure mps is the right unit here?
                    if (vel_mps < 70) vel_mps = 70;
                    if (vel_mps > 160) vel_mps = 160;                
                    */

                    /*
                    AiAirWayPointType aawpt = AiAirWayPointType.AATTACK_FIGHTERS;
                    if ((nextWP as AiAirWayPoint).Action != AiAirWayPointType.LANDING && (nextWP as AiAirWayPoint).Action != AiAirWayPointType.TAKEOFF)
                        aawpt = (nextWP as AiAirWayPoint).Action;
                    else
                    {
                        string type = "";
                        string t = aircraft.Type().ToString();
                        if (t.Contains("Fighter") || t.Contains("fighter")) type = "F";
                        else if (t.Contains("Bomber") || t.Contains("bomber")) type = "B";

                        if (type == "B") aawpt = AiAirWayPointType.NORMFLY;

                    }
                    */
                    if (!foundAirport)
                    {
                        //OK, skipping all that now & just making all ending/exitin waypoints LANDING so that hopefully many a/c can just disapparate.  2020/04/01
                        AiAirWayPointType aawpt = AiAirWayPointType.LANDING;

                        //add the mid Point
                        //midaaWP = new AiAirWayPoint(ref midPos, speed);
                        midaaWP = new AiAirWayPoint(ref midPos, 135); //135mps = 300mph.  Trying to get them to **move off the map** as quick as possible.
                                                                      //aaWP.Action = AiAirWayPointType.NORMFLY;
                        midaaWP.Action = aawpt; //same action for mid & end

                        NewWaypoints.Add(midaaWP); //do add
                        count++;


                        Console.WriteLine("FixWayPoints - no airport found/adding new mid-end WP: {0} {1:n0} {2:n0} {3:n0} {4:n0}", new object[] { aawpt, (midaaWP as AiAirWayPoint).Speed, midaaWP.P.x, midaaWP.P.y, midaaWP.P.z });

                        //add the final Point, which is off the map
                        //endaaWP = new AiAirWayPoint(ref endPos, speed);
                        endaaWP = new AiAirWayPoint(ref endPos, 135); //135mps = 300mph.  Trying to get them to **move off the map** as quick as possible.  Presumably if they find an airport & land they will slow down as needed.
                                                                      //aaWP.Action = AiAirWayPointType.NORMFLY;
                                                                      //endaaWP.Action = AiAirWayPointType.NORMFLY;
                        endaaWP.Action = AiAirWayPointType.LANDING;

                        NewWaypoints.Add(endaaWP); //do add
                        count++;
                        Console.WriteLine("FixWayPoints - no airport found/adding new end WP TO FLY OFF MAP: {0} {1:n0} {2:n0} {3:n0} {4:n0}", new object[] { aawpt, (endaaWP as AiAirWayPoint).Speed, endaaWP.P.x, endaaWP.P.y, endaaWP.P.z });
                    }
                }
                catch (Exception ex) { Console.WriteLine("MoveBomb FixWayPoints #4: " + ex.ToString()); }
            }
      

            if (update)
            {
                //Console.WriteLine("MBTITG: Updating this course");
                airGroup.SetWay(NewWaypoints.ToArray());

                //for testing

                /*
                try
                {

                    foreach (AiWayPoint wp in NewWaypoints)
                    {
                        Console.WriteLine("FixWayPoints - Target after: {0} {1:n0} {2:n0} {3:n0} {4:n0}", new object[] { (wp as AiAirWayPoint).Action, (wp as AiAirWayPoint).Speed, wp.P.x, wp.P.y, wp.P.z });
                    }


                }
                catch (Exception ex) { Console.WriteLine("MoveBomb FixWayPoints #5: " + ex.ToString()); }
                */



            }
        }
        catch (Exception ex) { Console.WriteLine("MoveBomb FixWayPoints: " + ex.ToString()); }
    }
    



    public override void OnTickGame()
    {
        base.OnTickGame();

        //if (Time.tickCounter() % 305 == 41) //about 1.5 seconds?
        //if (Time.tickCounter() > 2100 * 10 && Time.tickCounter() % 2105 == 41) //about 5 seconds?  2020/03/31
        //~2000 ticks/minute.  Or so.
        if (Time.tickCounter() > 2100 * 8 && Time.tickCounter() % 2105 == 41) //about 1 min 5 seconds?  2020/03/31.  Wait 8 mins before starting so that people get into place etc & if a lot of players are in we can just remove AIs from the map.
        {
            //Console.WriteLine("Movebomb: Checking movement new groups");
            Task.Run(() => checkNewAirgroups());
            //checkNewAirgroups();
        }
    }


    public override void OnTrigger(int missionNumber, string shortName, bool active)
    {
        base.OnTrigger(missionNumber, shortName, active);

        /*
        if (shortName.Equals("trigger"))
        {
            GamePlay.gpGetTrigger(shortName).Enable = false;

            List<AiWayPoint> NewWaypoints = new List<AiWayPoint>();

            NewWaypoints.Add(CurrentPosWaypoint(airGroup));
            NewWaypoints.AddRange(WaitingWayPoints(GetXYCoord(airGroup), 4000.0, 80.0, 10000.0, 5000.0, 20, AiAirWayPointType.HUNTING));

            NewWaypoints.AddRange(SetWaypointBetween(airGroup.Pos(), AirGroupAirfield.Pos(), 4000, 90.0));

            NewWaypoints.Add(GetLandingWaypoint(AirGroupAirfield, 1000.0));

            airGroup.SetWay(NewWaypoints.ToArray());
        }

        if (shortName.Equals("AttackTrigger"))
        {

            GamePlay.gpGetTrigger(shortName).Enable = false;

            AiAirGroup TestGroup = getNearestEnemyAirgroup(airGroup);

            if (TestGroup != null)
            {
                Console.WriteLine( "N�chste Airgroup: {0}", new object[] { TestGroup.Name() });
            }

            if (getDistanceToNearestEnemyAirgroup(airGroup).HasValue)
            {
                if (getDistanceToNearestEnemyAirgroup(airGroup).Value < 10000.0)
                {
                    Console.WriteLine( "Entfernung: {0}", new object[] { getDistanceToNearestEnemyAirgroup(airGroup).Value });
                    airGroup.setTask(AiAirGroupTask.ATTACK_AIR, TestGroup);
                }
            }
        }
        */
    }


    //So, I_FuelReserve never shows anything.  Maybe for launcher client only?
    //S_FuelReserve, -1 shows the TOTAL fuel available
    //S_FuelReserve, 0-x shows the amount in each of 2-3-4, however many, tanks in the aircraft.  The total of all the 0-x tanks always equals the -1 total
    //S_GunReserver, -1 doesn't seem to show anything at all and to get the total Gunreserve you have to total the S_GunServe, 0-x to get ammo in each area
    //Z_VelocityTAS gives the same for -1 and any x

    public double getAircraftFuel(AiAircraft aircraft)
    {
        double sFuel = -1;
        try
        {
            sFuel = aircraft.getParameter(part.ParameterTypes.S_FuelReserve, -1); // kgs
        }
        catch (Exception ex) { }
        return sFuel;
    }

    public int getAircraftAmmo(AiAircraft aircraft)
    {
        int ammo = -1;
        for (int i = 0; i < 9; i++)
        {
            try
            {
                ammo += (int)(aircraft.getParameter(part.ParameterTypes.S_GunReserve, i)); // qty
            }
            catch (Exception ex) { }
        };
        return ammo;
    }

    //returns the MAX of ammo in any aircraft in the airgroup
    //idea being, if any plane has enough ammo to attack, then the AG should be able to attack
    //they shouldn't turn off the attack just because (say) one or two a/c are low on ammo - only if the ALL are
    public int getAircraftAmmo(AiAirGroup airGroup)
    {
        int ammo = -1;
// Added null check to prevent crashes.
        if (airGroup == null || object == null || airGroup.GetItems().Length == 0) return -1;

        foreach (AiAircraft a in airGroup.GetItems())
        {
            int ammo_temp = getAircraftAmmo(a);
            if (ammo_temp > ammo) ammo = ammo_temp;
        }
        
        return ammo;
    }




    //  AiAirGroup airGroup = aircraft.AirGroup();
    // if(aircraft == airGroup.GetItems()[0])		        
    public double reportAircraftFuel(AiAircraft aircraft)
    {
        double speed=0;
        double sFuel = 0;
        double iFuel = 0;
        try
        {

            //So, I_FuelReserve never shows anything.  Maybe for launcher client only?
            //S_FuelReserve, -1 shows the TOTAL fuel available
            //S_FuelReserve, 0-x shows the amount in each of 2-3-4, however many, tanks in the aircraft.  The total of all the 0-x tanks always equals the -1 total
            //S_GunReserver, -1 doesn't seem to show anything at all and to get the total Gunreserve you have to total the S_GunServe, 0-x to get ammo in each area
            //Z_VelocityTAS gives the same for -1 and any x

            try
            {

                speed = aircraft.getParameter(part.ParameterTypes.Z_VelocityTAS, -1);
            }
            catch (Exception ex) {}
            try
            {
                sFuel = aircraft.getParameter(part.ParameterTypes.S_FuelReserve, -1); // kgs
            }

            catch (Exception ex) { }


            //So, this one doesn't seem to work at all?
            try
            {
                iFuel = aircraft.getParameter(part.ParameterTypes.I_FuelReserve, -1); // kgs
            }

            catch (Exception ex) { }

            int ammo = 0;
            try
            {
                ammo += (int)(aircraft.getParameter(part.ParameterTypes.S_GunReserve, -1)); // qty
            }
            catch (Exception ex) { }

            //Console.WriteLine("MoveBomb: Aircraft levels speed {0:N0} ammo {1:N0} sFuel {2:N0} iFuel {3:N0} {4}", speed, ammo, sFuel, iFuel, aircraft.InternalTypeName());
            for (int i = 0; i < 9; i++)
            {
                try
                {
                    ammo += (int)(aircraft.getParameter(part.ParameterTypes.S_GunReserve, i)); // qty
                }
                catch (Exception ex) { }
                try
                {
                    sFuel += (int)(aircraft.getParameter(part.ParameterTypes.S_FuelReserve, i)); // qty
                }
                catch (Exception ex) { }
                try
                {
                    iFuel += (int)(aircraft.getParameter(part.ParameterTypes.I_FuelReserve, i)); // qty		
                }
                catch (Exception ex) { }
                //Console.WriteLine("MoveBomb: Aircraft levels {5} speed {0:N0} ammo {1:N0} sFuel {2:N0} iFuel {3:N0} {4}", speed, ammo, sFuel, iFuel, aircraft.InternalTypeName(), i);

            };

            /* //not sure of the reasoning behind this bit?
            if (ammo == 0 || sFuel < 20)

                sFuel += 40;
            iFuel += 40;
            ammo += 1;
            */
            //Console.WriteLine("MoveBomb: Aircraft levels speed {0:N0} ammo {1:N0} sFuel {2:N0} iFuel {3:N0} {4}", speed, ammo, sFuel, iFuel, aircraft.InternalTypeName());
            return iFuel;
        }
        catch (Exception ex) { Console.WriteLine("MoveBomb Fuelreport ERROR: " + ex.ToString()); return -1; }

    }
}

//Various helpful calculations, formulas, etc.
public static class Calcs
{
    //Various public/static methods
    //http://stackoverflow.com/questions/6499334/best-way-to-change-dictionary-key    

    private static Random clc_random = new Random();

    public static bool changeKey<TKey, TValue>(this IDictionary<TKey, TValue> dict, TKey oldKey, TKey newKey)
    {
        TValue value;
        if (!dict.TryGetValue(oldKey, out value))
            return false;

        dict.Remove(oldKey);  // do not change order
        dict[newKey] = value;  // or dict.Add(newKey, value) depending on ur comfort
        return true;
    }

    //gets LAST occurence of any element of a specified string[] ; CASE INSENSITIVE
    public static int LastIndexOfAny(string test, string[] values)
    {
        int last = -1;
        test = test.ToLower();
        foreach (string item in values)
        {
            int i = test.IndexOf(item.ToLower());
            if (i >= 0)
            {
                if (last > 0)
                {
                    if (i > last)
                    {
                        last = i;
                    }
                }
                else
                {
                    last = i;
                }
            }
        }
        return last;
    }

    public static string escapeColon(string s)
    {
        return s.Replace("##", "##*").Replace(":", "##@");
    }

    public static string unescapeColon(string s)
    {
        return s.Replace("##@", ":").Replace("##*", "##");
    }

    public static string escapeSemicolon(string s)
    {
        return s.Replace("%%", "%%*").Replace(";", "%%@");
    }

    public static string unescapeSemicolon(string s)
    {
        return s.Replace("%%@", ";").Replace("%%*", "%%");
    }

    public static double distance(double a, double b)
    {

        return (double)Math.Sqrt(a * a + b * b);

    }

    public static double meters2miles(double a)
    {

        return (a / 1609.344);

    }

    public static double meterspsec2milesphour(double a)
    {
        return (a * 2.23694);
    }

    public static double meters2feet(double a)
    {

        return (a / 1609.344 * 5280);

    }


    public static double DegreesToRadians(double degrees)
    {
        return degrees * (Math.PI / 180.0);
    }

    public static double RadiansToDegrees(double radians)
    {
        return radians * (180.0 / Math.PI);
    }

    public static double CalculateGradientAngle(
                          Point3d startPoint,
                          Point3d endPoint)
    {
        //Calculate the length of the adjacent and opposite
        double diffX = endPoint.x - startPoint.x;
        double diffY = endPoint.y - startPoint.y;

        //Calculates the Tan to get the radians (TAN(alpha) = opposite / adjacent)
        //Math.PI/2 - atan becase we need to change to bearing where North =0, East = 90 vs regular math coordinates where East=0 and North=90.
        double radAngle = Math.PI / 2 - Math.Atan2(diffY, diffX);

        //Converts the radians in degrees
        double degAngle = RadiansToDegrees(radAngle);

        if (degAngle < 0)
        {
            degAngle = degAngle + 360;
        }

        return degAngle;
    }

    public static int GetDegreesIn10Step(double degrees)
    {
        degrees = Math.Round((degrees / 10), MidpointRounding.AwayFromZero) * 10;

        if ((int)degrees == 360)
            degrees = 0.0;

        return (int)degrees;
    }

    public static double CalculatePointDistance(
                        Point3d startPoint,
                        Point3d endPoint)
    {
        //Calculate the length of the adjacent and opposite
        double diffX = Math.Abs(endPoint.x - startPoint.x);
        double diffY = Math.Abs(endPoint.y - startPoint.y);

        return distance(diffX, diffY);
    }
    public static double CalculatePointDistance(
                        Vector3d startPoint,
                        Vector3d endPoint)
    {
        //Calculate the length of the adjacent and opposite
        double diffX = Math.Abs(endPoint.x - startPoint.x);
        double diffY = Math.Abs(endPoint.y - startPoint.y);

        return distance(diffX, diffY);
    }
    public static double CalculatePointDistance(
                        Point3d startPoint)
    {
        //Calculate the length of the adjacent and opposite
        double diffX = Math.Abs(startPoint.x);
        double diffY = Math.Abs(startPoint.y);

        return distance(diffX, diffY);
    }
    public static double CalculatePointDistance(
                        Vector3d startPoint)
    {
        //Calculate the length of the adjacent and opposite
        double diffX = Math.Abs(startPoint.x);
        double diffY = Math.Abs(startPoint.y);

        return distance(diffX, diffY);
    }

    public static double CalculateBearingDegree(Vector3d vector)
    {
        Vector2d matVector = new Vector2d(vector.y, vector.x);
        // the value of direction is in rad so we need *180/Pi to get the value in degrees.  We subtract from pi/2 to convert to compass directions

        double bearing = (matVector.direction()) * 180.0 / Math.PI;
        return (bearing > 0.0 ? bearing : (360.0 + bearing));
    }


    public static double CalculateBearingDegree(Vector2d vector)
    {
        Vector2d newVector = new Vector2d(vector.y, vector.x);
        // the value of direction is in rad so we need *180/Pi to get the value in degrees.  We subtract from pi/2 to convert to compass directions
        double bearing = (newVector.direction()) * 180.0 / Math.PI;
        return (bearing > 0.0 ? bearing : (360.0 + bearing));  //we want bearing to be 0-360, generally
    }

    public static double CalculatePitchDegree(Vector3d vector)
    {
        double d = distance(vector.x, vector.y);  //size of vector in x/y plane
        Vector2d matVector = new Vector2d(d, vector.z);
        // the value of direction is in rad so we need *180/Pi to get the value in degrees.  

        double pitch = (matVector.direction()) * 180.0 / Math.PI;
        return (pitch < 180 ? pitch : (pitch - 360.0)); //we want pitch to be between -180 and 180, generally
    }



    public static int TimeSince2016_sec()
    {
        DateTime epochStart = new DateTime(2016, 1, 1); //we need to fit this into an int; Starting 2016/01/01 it should last longer than CloD does . . . 
        DateTime currentDate = DateTime.Now;

        long elapsedTicks = currentDate.Ticks - epochStart.Ticks;
        int elapsedSeconds = (int)(elapsedTicks / 10000000);
        return elapsedSeconds;
    }

    public static long TimeSince2016_ticks()
    {
        DateTime epochStart = new DateTime(2016, 1, 1); //we need to fit this into an int; Starting 2016/01/01 it should last longer than CloD does . . . 
        DateTime currentDate = DateTime.Now;

        long elapsedTicks = currentDate.Ticks - epochStart.Ticks;
        return elapsedTicks;
    }

    public static long TimeNow_ticks()
    {
        DateTime currentDate = DateTime.Now;
        return currentDate.Ticks;
    }

    public static string SecondsToFormattedString(int sec)
    {
        try
        {
            var timespan = TimeSpan.FromSeconds(sec);
            if (sec < 10 * 60) return timespan.ToString(@"m\mss\s");
            if (sec < 60 * 60) return timespan.ToString(@"m\m");
            if (sec < 24 * 60 * 60) return timespan.ToString(@"hh\hmm\m");
            else return timespan.ToString(@"d\dhh\hmm\m");
        }
        catch (Exception ex)
        {
            System.Console.WriteLine("Calcs.SecondsToFormatted - Exception: " + ex.ToString());
            return sec.ToString();
        }
    }

    //returns index of largest array element which is equal to OR less than the value
    //assumes a sorted list of in values. 
    //If less than the 1st element or array empty, returns -1
    public static Int32 array_find_equalorless(int[] arr, Int32 value)
    {
// Added null check to prevent crashes.
        if (arr == null || object == null || arr.GetLength(0) == 0 || value < arr[0]) return -1;
        int index = Array.BinarySearch(arr, value);
        if (index < 0)
        {
            index = ~index - 1;
        }
        if (index < 0) return -1;
        return index;
    }

    //Splits a long string into a maxLineLength respecting word boundaries (IF possible)
    //http://stackoverflow.com/questions/22368434/best-way-to-split-string-into-lines-with-maximum-length-without-breaking-words
    public static IEnumerable<string> SplitToLines(string stringToSplit, int maxLineLength)
    {
        string[] words = stringToSplit.Split(' ');
        StringBuilder line = new StringBuilder();
        foreach (string word in words)
        {
            if (word.Length + line.Length <= maxLineLength)
            {
                line.Append(word + " ");
            }
            else
            {
                if (line.Length > 0)
                {
                    yield return line.ToString().Trim();
                    line.Clear();
                }
                string overflow = word;
                while (overflow.Length > maxLineLength)
                {
                    yield return overflow.Substring(0, maxLineLength);
                    overflow = overflow.Substring(maxLineLength);
                }
                line.Append(overflow + " ");
            }
        }
        yield return line.ToString().Trim();
    }

    //Salmo @ http://theairtacticalassaultgroup.com/forum/archive/index.php/t-4785.html
    public static string GetAircraftType(AiAircraft aircraft)
    { // returns the type of the specified aircraft
        string result = null;
        if (aircraft != null)
        {
            string type = aircraft.InternalTypeName(); // eg type = "bob:Aircraft.Bf-109E-3".  FYI this is a property of AiCart inherited by AiAircraft as a descendant class.  So we could do this with any type of AiActor or AiCart
            string[] part = type.Trim().Split('.');
            result = part[1]; // get the part after the "." in the type string
        }
        return result;
    }

    public static string randSTR(string[] strings)
    {
        //Random clc_random = new Random();
        return strings[clc_random.Next(strings.Length)];
    }

    public static int gpNumberOfPlayers(this IGamePlay GamePlay)
    {   // Purpose: Returns the number of human players in the game.
        // Use: GamePlay.NumberOfPlayers(); 
        int result = 0;

        //multiplayer
        if (GamePlay.gpRemotePlayers() != null || GamePlay.gpRemotePlayers().Length > 0)
        {
            return GamePlay.gpRemotePlayers().ToList().Count;
        }
        //singleplayer
        else if (GamePlay.gpPlayer() != null)
        {
            result = 1;
        }
        return result;
    }

    public static int gpNumberOfPlayers(this IGamePlay GamePlay, int army)
    {   // Purpose: Returns the number of human players in the game in the 
        //          specified army.
        // Use: GamePlay.NumberOfPlayers(army); 
        int result = 0;
        if (GamePlay.gpRemotePlayers() != null || GamePlay.gpRemotePlayers().Length > 0)
        {
            List<Player> players = new List<Player>(GamePlay.gpRemotePlayers());
            for (int i = 0; i < players.Count; i++)
            {
                if (players[i].Army() == army) result += 1;
            }
        }
        // on Dedi the server:
        else if (GamePlay.gpPlayer() != null)
        {
            if (GamePlay.gpPlayer().Army() == army) return 1;
            result = 0;
        }
        return result;
    }
    public static int gpNumberOfPlayersActive(this IGamePlay GamePlay, int army)
    {   // Purpose: Returns the number of human players in the game in the 
        //          specified army, who are in planes and in the air.
        // Use: GamePlay.NumberOfPlayersActive(GamePlay, army); 
        int result = 0;
        if (GamePlay.gpRemotePlayers() != null || GamePlay.gpRemotePlayers().Length > 0)
        {
            List<Player> players = new List<Player>(GamePlay.gpRemotePlayers());
            for (int i = 0; i < players.Count; i++)
            {
                if (players[i].Army() == army)
                {
// Added null check to prevent crashes.
                    if (players[i].Place() == null || object == null) continue;
// Added null check to prevent crashes.
                    if (players[i].Place() as AiAircraft == null || object == null) continue;
                    AiAircraft aircraft = players[i].Place() as AiAircraft;
                    double altAGL_m = aircraft.getParameter(part.ParameterTypes.Z_AltitudeAGL, 0);
                    if (altAGL_m > 5) result += 1;  //only count players in plane & off the ground/in flight
                }
            }
        }
        // on Dedi the server:
        else if (GamePlay.gpPlayer() != null)
        {
            if (GamePlay.gpPlayer().Army() == army) return 1;
            result = 0;
        }
        return result;
    }

    public static bool isHeavyBomber(AiAircraft aircraft)
    {
// Added null check to prevent crashes.
        if (aircraft == null || object == null) return false;
        string acType = GetAircraftType(aircraft);
        return isHeavyBomber(acType);
    }

    public static bool isHeavyBomber(AiAirGroup airGroup)
    {
        AiAircraft aircraft = null;
        if (airGroup != null && airGroup.GetItems().Length > 0 && (airGroup.GetItems()[0] as AiAircraft) != null) aircraft = airGroup.GetItems()[0] as AiAircraft;
        return isHeavyBomber(aircraft);

    }
    public static bool isHeavyBomber(string acType)
    {
        if (acType == "") return false;
        bool ret = false;
        if (acType.Contains("Ju-88") || acType.Contains("He-111") || acType.Contains("BR-20") || acType.Contains("BlenheimMkI") || acType.Contains("Do-17") || acType.Contains("Wellington")
         || acType.Contains("Sunderland") || acType.Contains("HurricaneMkI_FB")) ret = true; //Contains("BlenheimMkI" includes BI, BIV, BIV Late, etc.
        if (acType.Contains("BlenheimMkIVF") || acType.Contains("BlenheimMkIVNF") || acType.Contains("BlenheimMkIF") || acType.Contains("BlenheimMkINF")) ret = false;
        return ret;
    }
    public static bool isDiveBomber(AiAircraft aircraft)
    {
// Added null check to prevent crashes.
        if (aircraft == null || object == null) return false;
        string acType = GetAircraftType(aircraft);
        return isDiveBomber(acType);
    }
    public static bool isDiveBomber(AiAirGroup airGroup)
    {
        AiAircraft aircraft = null;
        if (airGroup != null && airGroup.GetItems().Length > 0 && (airGroup.GetItems()[0] as AiAircraft) != null) aircraft = airGroup.GetItems()[0] as AiAircraft;
        return isDiveBomber(aircraft);

    }
    public static bool isDiveBomber(string acType)
    {
        if (acType == "") return false;
        bool ret = false;
        if (acType.Contains("Ju-87")) ret = true; //only JU-87 now, but maybe more later?   HurriFB definitely won't dive-bomb
        return ret;
    }



// *** Critical Game Flow Area ***
// This section manages mission events and interactions.
    public static void loadSmokeOrFire(maddox.game.IGamePlay GamePlay, Mission mission, double x, double y, double z, string type, double duration_s = 300, string path = "")
    {
        /* Samples: 
         * Static555 Smoke.Environment.Smoke1 nn 63748.22 187791.27 110.00 /height 16.24
        Static556 Smoke.Environment.Smoke1 nn 63718.50 187780.80 110.00 /height 16.24
        Static557 Smoke.Environment.Smoke2 nn 63688.12 187764.03 110.00 /height 16.24
        Static534 Smoke.Environment.BuildingFireSmall nn 63432.15 187668.28 110.00 /height 15.08
        Static542 Smoke.Environment.BuildingFireBig nn 63703.02 187760.81 110.00 /height 15.08
        Static580 Smoke.Environment.BigSitySmoke_0 nn 63561.45 187794.80 110.00 /height 17.01
        Static580 Smoke.Environment.BigSitySmoke_1 nn 63561.45 187794.80 110.00 /height 17.01

        Not sure if height is above sea level or above ground level.
        */

        mission.Timeout(2.0, () => { GamePlay.gpLogServer(null, "Testing the timeout (delete)", new object[] { }); });
        //GamePlay.gpLogServer(null, "Setting up to delete stationary smokes in " + duration_s.ToString("0.0") + " seconds.", new object[] { });
        mission.Timeout(3.0, () => { GamePlay.gpLogServer(null, "Testing the timeout (delete2)", new object[] { }); });
        mission.Timeout(4.0, () => { GamePlay.gpLogServer(null, "Testing the timeout (delete3)", new object[] { }); });
        mission.Timeout(4.5, () => { GamePlay.gpLogServer(null, "Testing the timeout (delete4)", new object[] { }); });

        mission.Timeout(5.0, () => {
            GamePlay.gpLogServer(null, "Executing the timeout (delete5)", new object[] { });
            //Point2d P = new Point2d(x, y);
            //GamePlay.gpRemoveGroundStationarys(P, 10);
        });
        /*
        mission.Timeout(duration_s, () =>
        {
            //Console.WriteLine("Deleting stationary smokes . . . ");
            GamePlay.gpLogServer(null, "Deleting stationary smokes . . . ", new object[] { });
            Point2d P = new Point2d(x, y);
            GamePlay.gpRemoveGroundStationarys(P, 10);
            foreach (GroundStationary sta in GamePlay.gpGroundStationarys(x, y, z + 1))
            {
// Added null check to prevent crashes.
                if (sta == null || object == null) continue;
                Console.WriteLine("Deleting , , , " + sta.Name + " " + sta.Title);
                if (sta.Name.Contains(key) || sta.Title.Contains(key)) {
                    Console.WriteLine("Deleting stationary smoke " + sta.Name + " - end of life");
                    sta.Destroy();
                }
            }


        });

     */
        //AMission mission = GamePlay as AMission;
        ISectionFile f = GamePlay.gpCreateSectionFile();
        string sect = "Stationary";
        string key = "Static1";
        string value = "Smoke.Environment." + type + " nn " + x.ToString("0.00") + " " + y.ToString("0.00") + " " + (duration_s / 60).ToString("0.0") + " /height " + z.ToString("0.00");
        f.add(sect, key, value);

        /*
        sect = "Stationary";
        key = "Static2";
        value = "Smoke.Environment." + "Smoke1" + " nn " + x.ToString("0.00") + " " + (y  + 130).ToString("0.00") + " 110.00 /height " + z.ToString("0.00");
        f.add(sect, key, value);

        sect = "Stationary";
        key = "Static3";
        value = "Smoke.Environment." + "Smoke2" + " nn " + x.ToString("0.00") + " " + (y + 260).ToString("0.00") + " 110.00 /height " + z.ToString("0.00");
        f.add(sect, key, value);

        sect = "Stationary";
        key = "Static4";
        value = "Smoke.Environment." + "BuildingFireSmall" + " nn " + x.ToString("0.00") + " " + (y + 390).ToString("0.00") + " 110.00 /height " + z.ToString("0.00");
        f.add(sect, key, value);

        sect = "Stationary";
        key = "Static5";
        value = "Smoke.Environment." + "BuildingFireBig" + " nn " + x.ToString("0.00") + " " + (y + 420).ToString("0.00") + " 110.00 /height " + z.ToString("0.00");
        f.add(sect, key, value);

        sect = "Stationary";
        key = "Static6";
        value = "Smoke.Environment." + "BigSitySmoke_0" + " nn " + x.ToString("0.00") + " " + (y + 550).ToString("0.00") + " 110.00 /height " + z.ToString("0.00");
        f.add(sect, key, value);

        sect = "Stationary";
        key = "Static7";
        value = "Smoke.Environment." + "BigSitySmoke_1" + " nn " + x.ToString("0.00") + " " + (y + 680).ToString("0.00") + " 110.00 /height " + z.ToString("0.00");
        f.add(sect, key, value);

        sect = "Stationary";
        key = "Static8";
        value = "Smoke.Environment." + "BigSitySmoke_2" + " nn " + x.ToString("0.00") + " " + (y + 710).ToString("0.00") + " 110.00 /height " + z.ToString("0.00");
        f.add(sect, key, value);
        */



        //maybe this part dies silently some times, due to f.save or perhaps section file load?  PRobably needs try/catch
        //GamePlay.gpLogServer(null, "Writing Sectionfile to " + path + "smoke-ISectionFile.txt", new object[] { }); //testing
        //f.save(path + "smoke-ISectionFile.txt"); //testing        

// *** Critical Game Flow Area ***
// This section manages mission events and interactions.
        GamePlay.gpPostMissionLoad(f);


        //TODO: This part isn't working; it never finds any of the smokes again.
        //get rid of it after the specified period



    }

    public static void PrintValues(IEnumerable myList, int myWidth)
    {
        int i = myWidth;
        foreach (Object obj in myList)
        {
            if (i <= 0)
            {
                i = myWidth;
// Removed empty Console.WriteLine(); to optimize performance.
            }
            i--;
            Console.Write("{0,8}", obj);
        }
// Removed empty Console.WriteLine(); to optimize performance.
    }



}